// src/hooks/useAdminCheck.js
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getUserInfo } from '../api/authv2';
import toast from 'react-hot-toast';

export const useAdminCheck = (onSuccess) => {
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuthAndRole = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          toast.error('No estás autenticado. Por favor, inicia sesión.');
          navigate('/auth/login');
          return;
        }

        const response = await getUserInfo();
        const userRole = response.user.role;

        if (userRole !== 'admin') {
          toast.error('Acceso denegado. Solo los administradores pueden ver esta página.');
          navigate('/user/profile');
          return;
        }

        // If role is admin, call the success callback
        if (onSuccess) {
          onSuccess();
        }
        setIsLoading(false);
      } catch (error) {
        console.error('Error checking authentication or role:', error);
        toast.error('Error al verificar tu autenticación. Por favor, inicia sesión.');
        navigate('/auth/login');
      }
    };

    checkAuthAndRole();
  }, [navigate, onSuccess]);

  return { isLoading };
};