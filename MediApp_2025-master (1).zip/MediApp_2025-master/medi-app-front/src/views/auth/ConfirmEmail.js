import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { confirmEmail } from "../../api/authv2";

export default function ConfirmEmail() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [isProcessed, setIsProcessed] = useState(false); // Prevent multiple navigations

  useEffect(() => {
    const verifyEmail = async () => {
      // If already processed, skip to avoid loops
      if (isProcessed) {
        console.log("Already processed, skipping...");
        return;
      }

      try {
        if (token) {
          console.log("Verifying token:", token);
          const response = await confirmEmail(token);
          console.log("API Response:", response);

          localStorage.setItem("token", response.token);
          toast.success("Correo confirmado exitosamente");

          // Mark as processed and navigate
          setIsProcessed(true);
          navigate("/user/profile", { replace: true }); // Use replace to avoid history stack issues
        } else {
          throw new Error("No token provided");
        }
      } catch (error) {
        console.error("Confirmation error:", error.message);
        toast.error(error.message || "Error al confirmar el correo");

        // Mark as processed and navigate
        setIsProcessed(true);
        navigate("/auth/login", { replace: true });
      }
    };

    verifyEmail();
  }, [token, navigate, isProcessed]); // Include isProcessed in dependencies

  return (
    <div className="container mx-auto px-4 h-full flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Verificando tu correo...</h2>
        <p>Por favor espera mientras confirmamos tu cuenta.</p>
      </div>
    </div>
  );
}