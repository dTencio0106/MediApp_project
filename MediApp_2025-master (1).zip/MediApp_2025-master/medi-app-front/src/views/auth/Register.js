import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { registerUser, getUserInfo } from "../../api/authv2";
import { useNavigate, Link } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

export default function Register() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();

  useEffect(() => {
    const checkUserRole = async () => {
      const token = localStorage.getItem("token");
      if (token) {
        try {
          const dataUser = await getUserInfo(token);
          if (dataUser.user.role === "admin") {
            navigate("/admin");
          } else {
            navigate("/user/profile");
          }
        } catch (error) {
          console.error("Error fetching user info:", error);
          localStorage.removeItem("token"); // Clear invalid token
          // Stay on the register page if token is invalid
        }
      }
    };

    checkUserRole();
  }, [navigate]);

  const onSubmit = handleSubmit(async (values) => {
    try {
      const data = await registerUser(values);
      toast.success("Registro exitoso. Por favor confirma tu correo electrónico antes de iniciar", { duration: 5000 });
    } catch (error) {
      toast.error(error.message || "Error al registrar");
    }
  });

  return (
    <div className="container mx-auto px-4 h-full">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="flex content-center items-center justify-center h-full">
        <div className="w-full lg:w-6/12 px-4">
          <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
            <div className="rounded-t mb-0 px-6 py-6">
              <div className="text-center mb-3">
                <h6 className="text-blueGray-500 text-sm font-bold">
                  Regístrate con
                </h6>
              </div>
              {/* Botones de terceros */}
              <hr className="mt-6 border-b-1 border-blueGray-300" />
            </div>
            <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
              <div className="text-blueGray-400 text-center mb-3 font-bold">
                <small>O regístrate con tus credenciales</small>
              </div>
              <form onSubmit={onSubmit}>
                {/* Nombre Completo */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Nombre Completo
                  </label>
                  <input
                    type="text"
                    {...register("nombreCompleto", {
                      required: "El nombre completo es obligatorio",
                      minLength: {
                        value: 3,
                        message: "El nombre completo debe tener al menos 3 caracteres",
                      },
                      maxLength: {
                        value: 100,
                        message: "El nombre completo no puede exceder 100 caracteres",
                      },
                      pattern: {
                        value: /^[a-zA-Z\s]+$/,
                        message: "El nombre completo solo puede contener letras y espacios",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Nombre Completo"
                  />
                  {errors.nombreCompleto && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.nombreCompleto.message}
                    </p>
                  )}
                </div>
                {/* Nombre de usuario */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Usuario
                  </label>
                  <input
                    type="text"
                    {...register("username", {
                      required: "El nombre es obligatorio",
                      minLength: {
                        value: 3,
                        message: "El nombre debe tener al menos 3 caracteres",
                      },
                      maxLength: {
                        value: 50,
                        message: "El nombre no puede exceder 50 caracteres",
                      },
                      pattern: {
                        value: /^[a-zA-Z0-9\s]+$/,
                        message: "El nombre solo puede contener letras, números y espacios",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Nombre"
                  />
                  {errors.username && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.username.message}
                    </p>
                  )}
                </div>
                {/* Correo */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Correo
                  </label>
                  <input
                    type="email"
                    {...register("email", {
                      required: "El correo es obligatorio",
                      pattern: {
                        value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                        message: "Por favor, ingresa un correo válido",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Correo"
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.email.message}
                    </p>
                  )}
                </div>
                {/* Contraseña */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Contraseña
                  </label>
                  <input
                    type="password"
                    {...register("password", {
                      required: "La contraseña es obligatoria",
                      minLength: {
                        value: 8,
                        message: "La contraseña debe tener al menos 8 caracteres",
                      },
                      pattern: {
                        value:
                          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
                        message:
                          "La contraseña debe incluir al menos una mayúscula, una minúscula, un número y un carácter especial (@$!%*?&)",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Contraseña"
                  />
                  {errors.password && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.password.message}
                    </p>
                  )}
                </div>
                {/* Cédula */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Cédula
                  </label>
                  <input
                    type="text"
                    {...register("cedula", {
                      required: "La cédula es obligatoria",
                      minLength: {
                        value: 5,
                        message: "La cédula debe tener al menos 5 caracteres",
                      },
                      pattern: {
                        value: /^[0-9-]+$/,
                        message: "La cédula solo puede contener números y guiones",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Cédula"
                  />
                  {errors.cedula && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.cedula.message}
                    </p>
                  )}
                </div>
                {/* Contacto de Emergencia */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Contacto de Emergencia
                  </label>
                  <input
                    type="text"
                    {...register("contactoEmergencia", {
                      required: "El contacto de emergencia es obligatorio",
                      pattern: {
                        value: /^[0-9+-\s]+$/,
                        message: "El contacto debe contener solo números, +, - o espacios",
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    placeholder="Contacto de Emergencia"
                  />
                  {errors.contactoEmergencia && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.contactoEmergencia.message}
                    </p>
                  )}
                </div>
                {/* Sexo */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Sexo
                  </label>
                  <select
                    {...register("sexo", {
                      required: "El sexo es obligatorio",
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  >
                    <option value="">Selecciona un sexo</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                    <option value="Otro">Otro</option>
                  </select>
                  {errors.sexo && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.sexo.message}
                    </p>
                  )}
                </div>
                {/* Fecha de Nacimiento */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Fecha de Nacimiento
                  </label>
                  <input
                    type="date"
                    {...register("fechaNacimiento", {
                      required: "La fecha de nacimiento es obligatoria",
                      validate: {
                        validDate: (value) => {
                          const today = new Date();
                          const birthDate = new Date(value);
                          return birthDate <= today || "La fecha de nacimiento no puede ser futura";
                        },
                        reasonableAge: (value) => {
                          const birthDate = new Date(value);
                          const age = (new Date().getFullYear() - birthDate.getFullYear());
                          return age <= 120 || "La edad no puede ser mayor a 120 años";
                        },
                      },
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  />
                  {errors.fechaNacimiento && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.fechaNacimiento.message}
                    </p>
                  )}
                </div>
                {/* Rol */}
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Rol
                  </label>
                  <select
                    {...register("role", {
                      required: "El rol es obligatorio",
                    })}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  >
                    <option value="">Selecciona un rol</option>
                    {/* <option value="admin">Administrador</option> */}
                    <option value="patient">Paciente</option>
                  </select>
                  {errors.role && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.role.message}
                    </p>
                  )}
                </div>
                <div className="text-center mt-6">
                  <button
                    className="bg-blueGray-800 text-white text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg w-full ease-linear transition-all duration-150"
                    type="submit"
                  >
                    Crear Cuenta
                  </button>
                </div>
              </form>
              <div className="mt-6 flex justify-between items-center">
                <span className="text-blueGray-500 text-sm">
                  ¿Ya tienes cuenta?{" "}
                  <Link to="/auth/login" className="text-lightBlue-500">
                    Inicia sesión
                  </Link>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}