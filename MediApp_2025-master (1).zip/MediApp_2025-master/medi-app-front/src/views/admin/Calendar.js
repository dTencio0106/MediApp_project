// src/components/auth/Calendar.jsx
import React, { useState, useCallback } from 'react';
import { Calendar as BigCalendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { getAppointments } from '../../api/appointments';
import { useAdminCheck } from '../../hooks/useAdminCheck';
import toast from 'react-hot-toast';
import Swal from 'sweetalert2'; // Import SweetAlert2

const localizer = momentLocalizer(moment);

export default function Calendar() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null); // State for selected appointment

  // Define fetchAppointments before using it in useAdminCheck
  const fetchAppointments = async () => {
    try {
      const data = await getAppointments();
      console.log('Appointments data:', data); // Debug: Log appointment data
      const formattedEvents = data.map((appointment) => ({
        title: appointment.titulo,
        start: new Date(appointment.fechaHora),
        end: new Date(moment(appointment.fechaHora).add(1, 'hour')), // Assuming each appointment lasts 1 hour
        desc: appointment.descripcion || 'Sin descripción', // Fallback for null/undefined
        paciente: appointment.paciente || 'No especificado', // Populated patient object
        creadaPor: appointment.creadaPor || 'No especificado', // Populated creator object
        id: appointment._id,
      }));
      setEvents(formattedEvents);
    } catch (error) {
      toast.error('Error al obtener citas');
    }
  };

  const onSuccess = useCallback(() => {
    fetchAppointments();
  }, []); // Memoized callback

  const { isLoading } = useAdminCheck(onSuccess); // Now fetchAppointments is defined

  // Handle event click to show SweetAlert2 modal
  const handleSelectEvent = (event) => {
    setSelectedEvent(event);
    Swal.fire({
      title: 'Detalles de la Cita',
      html: `
        <div style="text-align: left; font-family: Arial, sans-serif;">
          <p><strong>Título:</strong> ${event.title}</p>
          <p><strong>Descripción:</strong> ${event.desc}</p>
          <p><strong>Inicio:</strong> ${moment(event.start).format('DD/MM/YYYY HH:mm')}</p>
          <p><strong>Fin:</strong> ${moment(event.end).format('DD/MM/YYYY HH:mm')}</p>
          <p><strong>Paciente:</strong> ${event.paciente?.username || 'No especificado'}</p>
          <p><strong>Creada por:</strong> ${event.creadaPor?.username || 'No especificado'}</p>
        </div>
      `,
      confirmButtonText: 'Cerrar',
      confirmButtonColor: '#ef4444', // Matches bg-red-500
      customClass: {
        popup: 'swal2-popup',
        title: 'swal2-title',
        htmlContainer: 'swal2-html-container',
        confirmButton: 'swal2-confirm-button',
      },
      focusConfirm: true,
      didOpen: () => {
        // Optional: Add custom styling if needed
        const confirmButton = document.querySelector('.swal2-confirm-button');
        if (confirmButton) {
          confirmButton.style.fontWeight = 'bold';
          confirmButton.style.textTransform = 'uppercase';
          confirmButton.style.padding = '0.5rem 1.5rem';
          confirmButton.style.borderRadius = '0.25rem';
        }
      },
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="container mx-auto px-4 py-6">
          <h6 className="text-blueGray-700 text-xl font-bold mb-5">Calendario de Citas Agendadas</h6>
          <BigCalendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            style={{ height: 550 }}
            messages={{
              next: 'Siguiente',
              previous: 'Anterior',
              today: 'Hoy',
              month: 'Mes',
              week: 'Semana',
              day: 'Día',
              agenda: 'Agenda',
              date: 'Fecha',
              time: 'Hora',
              event: 'Evento',
            }}
            onSelectEvent={handleSelectEvent} // Click handler for SweetAlert2
          />
        </div>
      </div>
    </div>
  );
}