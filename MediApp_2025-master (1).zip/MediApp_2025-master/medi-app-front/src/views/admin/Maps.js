import React, { useState, useCallback } from "react";
import CardMedicalRecipe from "components/Cards/CardMedicalRecipe";
import CardMedicalRecipesTable from "components/Cards/CardMedicalRecipesTable";
import { getMedicalRecipes } from "../../api/recipes";
import toast from "react-hot-toast";
import { useAdminCheck } from "../../hooks/useAdminCheck";

export default function Maps() {
  const [recipes, setRecipes] = useState([]);
  const [recipeToEdit, setRecipeToEdit] = useState(null); // State for the recipe being edited

  // Define fetchRecipes before using it in useAdminCheck
  const fetchRecipes = async () => {
    try {
      const data = await getMedicalRecipes();
      setRecipes(data);
      // Clear editing state after fetching new data
      setRecipeToEdit(null);
    } catch (error) {
      toast.error("Error al obtener recetas médicas");
    }
  };

  const onSuccess = useCallback(() => {
    fetchRecipes();
  }, []); // Memoized callback

  const handleEdit = (recipe) => {
    setRecipeToEdit(recipe); // Set the recipe to edit
  };

  const handleCancelEdit = () => {
    setRecipeToEdit(null); // Clear the editing state
  };

  const { isLoading } = useAdminCheck(onSuccess);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-wrap">
        <div className="w-full px-4">
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <CardMedicalRecipe
              onRecipeAdded={fetchRecipes}
              recipeToEdit={recipeToEdit}
              onCancelEdit={handleCancelEdit}
            />
          </div>
        </div>
        <div className="w-full px-4">
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <CardMedicalRecipesTable
              recipes={recipes}
              onDelete={fetchRecipes}
              onEdit={handleEdit}
            />
          </div>
        </div>
      </div>
    </>
  );
}