import React from 'react';
import CardMedicalFormsTable from 'components/Cards/CardMedicalFormsTable';
import { useAdminCheck } from '../../hooks/useAdminCheck';

export default function MedicalForms() {
  const { isLoading } = useAdminCheck(() => {});

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <>
      <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
        <CardMedicalFormsTable />
      </div>
    </>
  );
}