import React, { useState } from "react";
import { createLaboratorio, getLaboratorios, deleteLaboratorio } from "../../api/laboratorios";
import { getPatients } from "../../api/patients";
import toast, { Toaster } from "react-hot-toast";
import { useAdminCheck } from "../../hooks/useAdminCheck";
import Swal from "sweetalert2";
import DynamicTable from "../../components/utils/DynamicTable";

const API_URL = process.env.REACT_APP_API_URL;

export default function Lab() {
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState("");
  const [files, setFiles] = useState([]);
  const [laboratorios, setLaboratorios] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);

  const fetchPatients = async () => {
    try {
      const data = await getPatients();
      setPatients(data);
    } catch (error) {
      toast.error("Error al obtener pacientes");
    }
  };

  const fetchLaboratorios = async () => {
    try {
      const data = await getLaboratorios();
      setLaboratorios(data);
    } catch (error) {
      toast.error("Error al obtener laboratorios");
    }
  };

  const onSuccess = React.useCallback(() => {
    fetchPatients();
    fetchLaboratorios();
  }, []);

  const { isLoading } = useAdminCheck(onSuccess);

  const handlePatientChange = (e) => {
    setSelectedPatient(e.target.value);
  };

  const handleFileChange = (e) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedPatient) {
      toast.error("Por favor, seleccione un paciente");
      return;
    }

    if (files.length === 0) {
      toast.error("Por favor, seleccione al menos un archivo");
      return;
    }

    const formData = new FormData();
    formData.append("paciente", selectedPatient);
    files.forEach((file) => {
      formData.append("archivos", file);
    });

    try {
      await createLaboratorio(formData);
      toast.success("Laboratorio creado exitosamente");
      fetchLaboratorios();
      setSelectedPatient("");
      setFiles([]);
    } catch (error) {
      toast.error("Error al crear el laboratorio");
    }
  };

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Estás seguro?",
      text: "¿Deseas archivar este laboratorio?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Sí, archivar",
      cancelButtonText: "No",
    });

    if (result.isConfirmed) {
      try {
        await deleteLaboratorio(id);
        toast.success("Laboratorio archivado exitosamente");
        fetchLaboratorios();
      } catch (error) {
        toast.error("Error al archivar el laboratorio");
      }
    }
  };

  const handleViewFile = (archivo) => {
    const fileUrl = `${API_URL}/laboratorio/file/${encodeURIComponent(archivo)}`;
    window.open(fileUrl, "_blank");
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString("es-MX", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
  };

  const columns = [
    {
      field: "paciente.username",
      header: "Paciente",
      body: (rowData) => rowData.paciente?.username || "N/A",
      filter: true, // Enable filtering
      filterPlaceholder: "Buscar por paciente",
    },
    {
      field: "createdAt",
      header: "Creado",
      body: (rowData) => formatTimestamp(rowData.createdAt),
      filter: true, // Enable filtering
      filterPlaceholder: "Buscar por fecha de creación",
      sortable: true, // Enable sorting
    },
    {
      field: "updatedAt",
      header: "Actualizado",
      body: (rowData) => formatTimestamp(rowData.updatedAt),
      filter: true, // Enable filtering
      filterPlaceholder: "Buscar por fecha de actualización",
      sortable: true, // Enable sorting
    },
    {
      field: "",
      header: "Acciones",
      body: (rowData) => (
        <div className="flex gap-2">
          {rowData.archivos.map((archivo, index) => (
            <button
              key={index}
              onClick={() => handleViewFile(archivo)}
              className="bg-blueGray-800 text-white font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none ease-linear transition-all duration-150"
            >
              Ver Archivo {index + 1}
            </button>
          ))}
          <button
            onClick={() => handleDelete(rowData._id)}
            className="bg-red-500 text-white active:bg-red-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none ease-linear transition-all duration-150"
          >
            Archivar
          </button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <h6 className="text-blueGray-700 text-xl font-bold">Laboratorios</h6>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form onSubmit={handleSubmit}>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Paciente
                </label>
                <select
                  name="paciente"
                  value={selectedPatient}
                  onChange={handlePatientChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                >
                  <option value="">Seleccione un paciente</option>
                  {patients.map((patient) => (
                    <option key={patient._id} value={patient._id}>
                      {patient.username}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Archivos
                </label>
                <input
                  type="file"
                  name="archivos"
                  onChange={handleFileChange}
                  multiple
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
              </div>
            </div>
          </div>
          <div className="text-center mt-6">
            <button
              type="submit"
              className="bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none ease-linear transition-all duration-150"
            >
              Guardar
            </button>
          </div>
        </form>
        <div className="mt-6">
          <h6 className="text-blueGray-700 text-xl font-bold">Laboratorios Registrados</h6>
          <DynamicTable
            data={laboratorios}
            columns={columns}
            name="LaboratoriosRegistrados"
            selection={selectedRow}
            onSelectionChange={(e) => setSelectedRow(e.value)}
            selectionMode="single"
            tableStyle={{ tableLayout: "auto" }}
            filters // Enable filtering (assuming DynamicTable supports this prop)
          />
        </div>
      </div>
    </div>
  );
}