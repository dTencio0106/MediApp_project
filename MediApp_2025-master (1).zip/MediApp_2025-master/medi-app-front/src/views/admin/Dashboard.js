import React, { useState, useCallback } from "react";
import CardAppointment from "components/Cards/CardAppointment";
import CardAppointmentsTable from "components/Cards/CardAppointmentsTable";
import { getAppointments } from "../../api/appointments";
import toast from "react-hot-toast";
import { useAdminCheck } from "../../hooks/useAdminCheck";

export default function Dashboard() {
  const [appointments, setAppointments] = useState([]);
  const [appointmentToEdit, setAppointmentToEdit] = useState(null); // State for editing

  const fetchAppointments = async () => {
    try {
      const data = await getAppointments();
      setAppointments(data);
      setAppointmentToEdit(null); // Clear editing state after fetching
    } catch (error) {
      toast.error("Error al obtener citas");
    }
  };

  const onSuccess = useCallback(() => {
    fetchAppointments();
  }, []); // Memoized callback

  const handleEdit = (appointment) => {
    setAppointmentToEdit(appointment); // Set the appointment to edit
  };

  const handleCancelEdit = () => {
    setAppointmentToEdit(null); // Clear the editing state
  };

  const { isLoading } = useAdminCheck(onSuccess);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-wrap justify-center mt-4 space-y-6 lg:space-y-0 lg:space-x-6">
        {/* Formulario para agregar cita */}
        <div className="w-full lg:w-1/2">
          <CardAppointment
            onAppointmentAdded={fetchAppointments}
            appointmentToEdit={appointmentToEdit}
            onCancelEdit={handleCancelEdit}
          />
        </div>

        {/* Tabla de citas agendadas */}
        <div className="w-full lg:w-1/2">
          <CardAppointmentsTable
            appointments={appointments}
            onDelete={fetchAppointments}
            onEdit={handleEdit}
          />
        </div>
      </div>
    </>
  );
}