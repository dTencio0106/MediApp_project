// src/components/auth/Reports.jsx
import React, { useState } from 'react';
import { Pie, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale } from 'chart.js';
import { getAppointments } from '../../api/appointments';
import { getPatients } from '../../api/patients';
import { getInventory } from '../../api/inventory';
import toast, { Toaster } from 'react-hot-toast';
import { useAdminCheck } from '../../hooks/useAdminCheck';

// Registrar los componentes de chart.js
ChartJS.register(ArcElement, Tooltip, Legend, BarElement, CategoryScale, LinearScale);

export default function Reports() {
  const [chartData, setChartData] = useState(null);
  const [barChartData, setBarChartData] = useState(null);
  const [inventoryChartData, setInventoryChartData] = useState(null);

  // Define fetch functions before using them in useAdminCheck
  const fetchAppointments = async () => {
    try {
      const data = await getAppointments();
      const monthlyData = getMonthlyData(data);
      setChartData({
        labels: Object.keys(monthlyData),
        datasets: [
          {
            label: 'Citas Agendadas',
            data: Object.values(monthlyData),
            backgroundColor: [
              '#FF6384',
              '#36A2EB',
              '#FF0042',
              '#2700FF',
              '#D500FF',
              '#FFCE56',
              '#00FFEC',
              '#FF5733',
              '#6F7496',
              '#ABABAB',
              '#00FFF0',
              '#901DA2',
            ],
          },
        ],
      });
    } catch (error) {
      toast.error('Error al obtener las citas');
    }
  };

  const fetchPatients = async () => {
    try {
      const responseData = await getPatients();
      const data = responseData.patients || responseData; // Handle wrapped or unwrapped response
      console.log('Patient data:', data); // Debug: Log patient data
      const ageData = getAgeData(data);
      if (Object.keys(ageData).length === 0) {
        toast.error('No hay datos válidos de pacientes para mostrar');
        setBarChartData(null);
        return;
      }
      setBarChartData({
        labels: Object.keys(ageData).map(age => `${age} años`),
        datasets: [
          {
            label: 'Pacientes por Edad',
            data: Object.values(ageData),
            backgroundColor: Object.keys(ageData).map(() => getRandomColor()),
          },
        ],
      });
    } catch (error) {
      toast.error('Error al obtener los pacientes');
    }
  };

  const fetchInventory = async () => {
    try {
      const data = await getInventory();
      setInventoryChartData({
        labels: data.map(item => item.nombre),
        datasets: [
          {
            label: 'Cantidad de Muestras',
            data: data.map(item => item.cantidad),
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
          },
        ],
      });
    } catch (error) {
      toast.error('Error al obtener el inventario');
    }
  };

  const onSuccess = React.useCallback(() => {
    fetchAppointments();
    fetchPatients();
    fetchInventory();
  }, []); // Empty dependency array, assuming all fetch functions are stable
  const { isLoading } = useAdminCheck(onSuccess);

  const getMonthlyData = (appointments) => {
    const monthlyData = {};
    appointments.forEach((appointment) => {
      const month = new Date(appointment.fechaHora).toLocaleString('es-ES', { month: 'long' });
      if (!monthlyData[month]) {
        monthlyData[month] = 0;
      }
      monthlyData[month]++;
    });
    return monthlyData;
  };

  const getAgeData = (patients) => {
    const ageData = {};
    const today = new Date();
    patients.forEach((patient, index) => {
      // Validate fechaNacimiento
      if (!patient.fechaNacimiento || typeof patient.fechaNacimiento !== 'string') {
        console.warn(`Paciente ${index} tiene fechaNacimiento inválida:`, patient.fechaNacimiento);
        return; // Skip invalid patient
      }

      const birthDate = new Date(patient.fechaNacimiento);
      if (isNaN(birthDate.getTime())) {
        console.warn(`Paciente ${index} tiene fechaNacimiento no válida:`, patient.fechaNacimiento);
        return; // Skip invalid date
      }

      // Calculate age in years
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      const dayDiff = today.getDate() - birthDate.getDate();

      // Adjust age if birthday hasn't occurred this year
      if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
        age--;
      }

      // Validate age
      if (age < 0 || age > 120) {
        console.warn(`Paciente ${index} tiene edad no válida: ${age}`, patient);
        return; // Skip unrealistic ages
      }

      if (!ageData[age]) {
        ageData[age] = 0;
      }
      ageData[age]++;
    });
    console.log('Calculated ageData:', ageData); // Debug: Log age distribution
    return ageData;
  };

  const getRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          font: {
            size: 12,
          },
          boxWidth: 20,
        },
      },
      tooltip: {
        enabled: true,
      },
    },
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
          callback: function(value) {
            return Number.isInteger(value) ? value : null;
          },
        },
      },
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 0,
          font: {
            size: 10,
          },
        },
      },
    },
    plugins: {
      legend: {
        position: 'top',
        labels: {
          font: {
            size: 12,
          },
          boxWidth: 20,
        },
      },
    },
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <h6 className="text-blueGray-700 text-xl font-bold">Reportes de gráficos</h6>
      </div>
      <div className="flex flex-col px-4 lg:px-10 py-10 pt-0 space-y-6">
        {/* Appointments Pie Chart */}
        <div className="w-full">
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <div className="rounded-t mb-0 px-4 py-3 border-0">
              <div className="flex flex-wrap items-center">
                <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                  <h3 className="font-semibold text-base text-blueGray-700">Reporte de Citas Agendadas por Mes</h3>
                </div>
              </div>
            </div>
            <div className="block w-full px-4 py-4">
              {chartData ? (
                <div className="w-full h-64 sm:h-80 md:h-96 lg:h-[500px] xl:h-[600px]">
                  <Pie data={chartData} options={chartOptions} />
                </div>
              ) : (
                <p className="p-5 text-center">Cargando datos...</p>
              )}
            </div>
          </div>
        </div>

        {/* Patients Bar Chart */}
        <div className="w-full">
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <div className="rounded-t mb-0 px-4 py-3 border-0">
              <div className="flex flex-wrap items-center">
                <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                  <h3 className="font-semibold text-base text-blueGray-700">Reporte de Pacientes por Edad</h3>
                </div>
              </div>
            </div>
            <div className="block w-full px-4 py-4">
              {barChartData ? (
                <div className="w-full h-64 sm:h-80 md:h-96 lg:h-[500px] xl:h-[600px]">
                  <Bar data={barChartData} options={barChartOptions} />
                </div>
              ) : (
                <p className="p-5 text-center">Cargando datos...</p>
              )}
            </div>
          </div>
        </div>

        {/* Inventory Bar Chart */}
        <div className="w-full">
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <div className="rounded-t mb-0 px-4 py-3 border-0">
              <div className="flex flex-wrap items-center">
                <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                  <h3 className="font-semibold text-base text-blueGray-700">Reporte de Inventario de Muestras por Cantidad</h3>
                </div>
              </div>
            </div>
            <div className="block w-full px-4 py-4">
              {inventoryChartData ? (
                <div className="w-full h-64 sm:h-80 md:h-96 lg:h-[500px] xl:h-[600px]">
                  <Bar data={inventoryChartData} options={barChartOptions} />
                </div>
              ) : (
                <p className="p-5 text-center">Cargando datos...</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}