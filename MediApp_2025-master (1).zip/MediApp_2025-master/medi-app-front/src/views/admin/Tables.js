import React, { useState, useCallback } from "react";
import CardConsultationForm from "components/Cards/CardConsultationForm";
import CardConsultationsTable from "components/Cards/CardConsultationsTable";
import { getConsultations } from "../../api/consultations";
import toast from "react-hot-toast";
import { useAdminCheck } from "../../hooks/useAdminCheck";

export default function Tables() {
  const [consultations, setConsultations] = useState([]);
  const [consultationToEdit, setConsultationToEdit] = useState(null); // State for editing

  const fetchConsultations = async () => {
    try {
      const data = await getConsultations();
      setConsultations(data);
      setConsultationToEdit(null); // Clear editing state after fetching
    } catch (error) {
      toast.error("Error al obtener consultas");
    }
  };

  const onSuccess = useCallback(() => {
    fetchConsultations();
  }, []); // Memoized callback

  const handleEdit = (consultation) => {
    setConsultationToEdit(consultation); // Set the consultation to edit
  };

  const handleCancelEdit = () => {
    setConsultationToEdit(null); // Clear the editing state
  };

  const { isLoading } = useAdminCheck(onSuccess);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-wrap mt-4">
        <div className="w-full mb-12 px-4">
          <CardConsultationForm
            onConsultationAdded={fetchConsultations}
            consultationToEdit={consultationToEdit}
            onCancelEdit={handleCancelEdit}
          />
        </div>
        <div className="w-full mb-12 px-4">
          <CardConsultationsTable
            consultations={consultations}
            onDelete={fetchConsultations}
            onEdit={handleEdit}
          />
        </div>
      </div>
    </>
  );
}