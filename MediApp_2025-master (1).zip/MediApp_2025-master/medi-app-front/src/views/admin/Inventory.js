import React, { useState, useCallback } from 'react';
import { getInventory, createInventory, updateInventory, deleteInventory } from '../../api/inventory';
import toast, { Toaster } from 'react-hot-toast';
import DynamicTable from '../../components/utils/DynamicTable';
import { useAdminCheck } from '../../hooks/useAdminCheck';
import Swal from 'sweetalert2'; // Import SweetAlert2

const API_URL = process.env.REACT_APP_API_URL;

export default function Inventory() {
  const [inventario, setInventario] = useState([]);
  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [cantidad, setCantidad] = useState(0);
  const [imagen, setImagen] = useState(null);
  const [inventoryToEdit, setInventoryToEdit] = useState(null); // State for editing
  const [selectedRow, setSelectedRow] = useState(null); // State for table selection

  const fetchInventario = async () => {
    try {
      const data = await getInventory();
      setInventario(data);
      setInventoryToEdit(null); // Clear editing state after fetching
    } catch (error) {
      toast.error('Error al obtener el inventario');
    }
  };

  const onSuccess = useCallback(() => {
    fetchInventario();
  }, []);

  const { isLoading } = useAdminCheck(onSuccess);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('nombre', nombre);
      formData.append('descripcion', descripcion);
      formData.append('cantidad', cantidad.toString());
      if (inventoryToEdit && !imagen) {
        formData.append('imagen', inventoryToEdit.imagen || ''); // Retain existing image if no new one is uploaded
      }
      if (imagen) {
        formData.append('imagen', imagen);
      }

      if (inventoryToEdit) {
        // Update existing inventory item
        await updateInventory(inventoryToEdit._id, formData);
        toast.success('Medicamento actualizado exitosamente!');
      } else {
        // Create new inventory item
        await createInventory(formData);
        toast.success('Medicamento de muestra agregado al inventario exitosamente!');
      }

      fetchInventario();
      resetForm();
    } catch (error) {
      toast.error(inventoryToEdit ? 'Error al actualizar el medicamento' : 'Error al agregar la muestra al inventario');
    }
  };

  const handleReduceQuantity = async (id, cantidad) => {
    try {
      const formData = new FormData();
      formData.append('cantidad', cantidad.toString());
      
      await updateInventory(id, formData);
      toast.success('Cantidad actualizada exitosamente');
      fetchInventario();
    } catch (error) {
      toast.error('Error al actualizar la cantidad');
    }
  };

  const handleEdit = (item) => {
    setInventoryToEdit(item);
    setNombre(item.nombre);
    setDescripcion(item.descripcion);
    setCantidad(item.cantidad);
    setImagen(null); // Reset image, user can upload a new one if needed
  };

  const handleDelete = async (id) => {
    // Show SweetAlert2 confirmation dialog
    const result = await Swal.fire({
      title: '¿Estás seguro?',
      text: '¿Deseas eliminar este medicamento del inventario? Esta acción no se puede deshacer.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
    });

    if (result.isConfirmed) {
      try {
        await deleteInventory(id);
        toast.success('Medicamento eliminado exitosamente');
        fetchInventario(); // Refresh the table
      } catch (error) {
        toast.error('Error al eliminar el medicamento');
      }
    }
  };

  const resetForm = () => {
    setNombre('');
    setDescripcion('');
    setCantidad(0);
    setImagen(null);
    setInventoryToEdit(null);
    setSelectedRow(null);
  };

  const columns = [
    { field: 'nombre', header: 'Nombre de muestra' },
    { field: 'descripcion', header: 'Descripción' },
    { field: 'cantidad', header: 'Cantidad' },
    {
      field: 'imagen',
      header: 'Imagen',
      body: (rowData) =>
        rowData.imagen ? (
          <a
            href={`${API_URL}/inventario/file/${encodeURIComponent(rowData.imagen)}`}
            download
          >
            <img
              src={`${API_URL}/inventario/file/${encodeURIComponent(rowData.imagen)}`}
              alt={rowData.nombre}
              style={{ maxWidth: '100px', maxHeight: '100px', cursor: 'pointer' }}
            />
          </a>
        ) : (
          'Sin imagen'
        ),
    },
    {
      field: '',
      header: 'Acciones',
      body: (rowData) => (
        <div className="flex align-items-center">
          <button
            className="text-white active:bg-blue-600 font-bold uppercase text-xs px-3 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none mr-2"
            style={{ backgroundColor: 'blue' }}
            onClick={() => handleEdit(rowData)}
          >
            Editar
          </button>
          <button
            className="text-white active:bg-red-600 font-bold uppercase text-xs px-3 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none mr-2"
            style={{
              backgroundColor: rowData.cantidad <= 0 ? 'gray' : 'red',
              cursor: rowData.cantidad <= 0 ? 'not-allowed' : 'pointer',
            }}
            onClick={() => handleReduceQuantity(rowData._id, (rowData.cantidad - 1))}
            disabled={rowData.cantidad <= 0}
          >
            <i className="fas fa-minus"></i>
          </button>
          <button
            className="text-white active:bg-green-600 font-bold uppercase text-xs px-3 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none mr-2"
            style={{ backgroundColor: 'green' }}
            onClick={() => handleReduceQuantity(rowData._id, (rowData.cantidad + 1))}
          >
            <i className="fas fa-plus"></i>
          </button>
          <button
            className="text-white active:bg-red-600 font-bold uppercase text-xs px-3 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none"
            style={{ backgroundColor: 'darkred' }}
            onClick={() => handleDelete(rowData._id)}
          >
            <i className="fas fa-trash"></i>
          </button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando... Verificando permisos.</p>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <h6 className="text-blueGray-700 text-xl font-bold">
          {inventoryToEdit ? "Editar Medicamento" : "Inventario"}
        </h6>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form onSubmit={handleSubmit}>
          <div className="flex flex-wrap mt-3">
            <div className="w-full lg:w-3/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Nombre de muestra
                </label>
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
              </div>
            </div>
            <div className="w-full lg:w-3/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Descripción
                </label>
                <input
                  type="text"
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
              </div>
            </div>
            <div className="w-full lg:w-3/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Cantidad
                </label>
                <input
                  type="number"
                  value={cantidad}
                  onChange={(e) => setCantidad(parseInt(e.target.value))}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  min="0"
                  max="500"
                  required
                />
              </div>
            </div>
            <div className="w-full lg:w-3/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Imagen
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setImagen(e.target.files ? e.target.files[0] : null)}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                />
                {inventoryToEdit && inventoryToEdit.imagen && !imagen && (
                  <div className="mt-2">
                    <p className="text-sm text-blueGray-600 mb-1">Imagen actual: </p>
                    <img
                      src={`${API_URL}/inventario/file/${encodeURIComponent(inventoryToEdit.imagen)}`}
                      alt="Imagen actual"
                      style={{ maxWidth: '150px', maxHeight: '150px', borderRadius: '5px' }}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="text-center mt-6">
            {inventoryToEdit && (
              <button
                type="button"
                className="bg-blueGray-800 text-white font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-4 ease-linear transition-all duration-150"
                onClick={resetForm}
              >
                Cancelar Edición
              </button>
            )}
            <button
              type="submit"
              className="bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none ease-linear transition-all duration-150"
            >
              {inventoryToEdit ? "Actualizar Medicamento" : "Agregar a inventario"}
            </button>
          </div>
        </form>
        <div className="mt-6">
          <DynamicTable
            data={inventario}
            columns={columns}
            name="InventarioMedicamentos"
            selection={selectedRow}
            onSelectionChange={(e) => setSelectedRow(e.value)}
            selectionMode="single"
          />
        </div>
      </div>
    </div>
  );
}