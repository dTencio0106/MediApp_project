// medi-app-front/src/views/user/Appointments.js
import React, { useState, useEffect } from "react";
import toast, { Toaster } from "react-hot-toast";
import CardPatientAppointmentsTable from "components/Cards/CardPatientAppointmentsTable";
import { getPatientAppointments } from "../../api/appointments";

export default function PatientAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        setLoading(true);
        const data = await getPatientAppointments();
        setAppointments(data);
      } catch (error) {
        toast.error("Error al obtener tus citas");
      } finally {
        setLoading(false);
      }
    };
    fetchAppointments();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 h-full flex items-center justify-center">
        <p>Cargando tus citas...</p>
      </div>
    );
  }

  return (
    <>
      <Toaster position="top-right" reverseOrder={false} />
      <div className="flex flex-wrap mt-4">
        <div className="w-full px-4">
          <CardPatientAppointmentsTable appointments={appointments} />
        </div>
      </div>
    </>
  );
}