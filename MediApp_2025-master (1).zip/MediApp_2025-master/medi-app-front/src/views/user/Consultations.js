import React, { useState, useEffect } from "react";
import { getConsultations } from "../../api/consultations";
import CardPatientConsultationsTable from "../../components/Cards/CardPatientConsultationsTable";
import toast, { Toaster } from "react-hot-toast";

export default function PatientConsultations() {
  const [consultations, setConsultations] = useState([]);

  useEffect(() => {
    const fetchConsultations = async () => {
      try {
        const data = await getConsultations();
        setConsultations(data);
      } catch (error) {
        toast.error("Error al obtener las consultas");
      }
    };
    fetchConsultations();
  }, []);

  return (
    <>
      <Toaster position="top-right" reverseOrder={false} />
      <div className="flex flex-wrap mt-4">
        <div className="w-full mb-12 px-4">
          <CardPatientConsultationsTable consultations={consultations} />
        </div>
      </div>
    </>
  );
}