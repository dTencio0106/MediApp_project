// medi-app-front/src/views/user/Profile.js
import React, { useCallback, useState } from "react";
import toast from "react-hot-toast";

// components
import CardAppointment from "components/Cards/CardAppointment";
import UserProfile from "components/Cards/CardUser";

export default function Profile() {
  const [appointmentToEdit, setAppointmentToEdit] = useState(null); // Optional: for editing support

  // Handle appointment creation/update
  const handleAppointmentAdded = useCallback(() => {
    //toast.success("Cita procesada exitosamente");
    setAppointmentToEdit(null); // Clear editing state
  }, []);

  // Handle canceling edit
  const handleCancelEdit = useCallback(() => {
    setAppointmentToEdit(null); // Clear editing state
  }, []);

  return (
    <>
      <div className="flex flex-wrap justify-center mt-4 space-y-6 lg:space-y-0 lg:space-x-6">
        <div className="w-full lg:w-1/2">
          <UserProfile />
          <CardAppointment
            onAppointmentAdded={handleAppointmentAdded}
            appointmentToEdit={appointmentToEdit}
            onCancelEdit={handleCancelEdit}
          />
        </div>
      </div>
    </>
  );
}