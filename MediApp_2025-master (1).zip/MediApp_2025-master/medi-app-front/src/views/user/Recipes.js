// src/views/user/PatientRecipes.js
import React, { useEffect, useState } from "react";
import CardPatientRecipesTable from "components/Cards/CardPatientRecipesTable.js";
import { getMedicalRecipes } from "api/recipes";

export default function PatientRecipes() {
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const data = await getMedicalRecipes();
        setRecipes(data);
      } catch (error) {
        console.error("Error al obtener las recetas:", error);
      }
    };
    fetchRecipes();
  }, []);

  return (
    <>
      <div className="flex flex-wrap mt-4">
        <div className="w-full mb-12 px-4">
          <CardPatientRecipesTable recipes={recipes} />
        </div>
      </div>
    </>
  );
}