// components/Dropdowns/UserDropdown.js
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

export default function UserDropdown() {
  const [dropdownPopoverShow, setDropdownPopoverShow] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/auth/login");
    toast.success("Sesión cerrada exitosamente");
  };

  return (
    <>
      <div
        className="text-blueGray-500 block cursor-pointer"
        onClick={() => setDropdownPopoverShow(!dropdownPopoverShow)}
      >
        <div className="items-center flex">
          <span className="w-12 h-12 text-sm text-white bg-blueGray-200 inline-flex items-center justify-center rounded-full">
            <i className="fas fa-user-circle text-3xl text-blueGray-600"></i>
          </span>
        </div>
      </div>
      <div
        className={
          (dropdownPopoverShow ? "block " : "hidden ") +
          "bg-white text-base absolute top-full right-0 z-50 py-2 list-none text-left rounded shadow-lg min-w-48"
        }
      >
        {/* <Link
          to="/profile"
          className="text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:bg-blueGray-100"
          onClick={() => setDropdownPopoverShow(false)}
        >
          Perfil
        </Link> */}
        <div className="h-0 my-2 border border-solid border-blueGray-100" />
        <button
          className="text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:bg-blueGray-100 text-left"
          onClick={() => {
            setDropdownPopoverShow(false);
            handleLogout();
          }}
        >
          Cerrar Sesión
        </button>
      </div>
    </>
  );
}