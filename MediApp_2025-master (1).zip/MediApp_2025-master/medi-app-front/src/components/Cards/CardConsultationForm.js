import React, { useState, useEffect } from "react";
import { createConsultation, updateConsultation } from "../../api/consultations";
import { getPatients } from "../../api/patients";
import toast, { Toaster } from "react-hot-toast";

export default function CardConsultationForm({ onConsultationAdded, consultationToEdit, onCancelEdit }) {
  const [form, setForm] = useState({
    _id: "",
    paciente: "", // Now an ObjectId
    sistolica: "",
    diastolica: "",
    frecuenciaCardiaca: "",
    saturacionOxigeno: "",
    temperatura: "",
    motivo: "",
    fecha: "",
  });
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);

  useEffect(() => {
    const loadPatients = async () => {
      try {
        const data = await getPatients();
        setPatients(data); // Store full patient objects
      } catch (error) {
        toast.error("Error al cargar los pacientes");
      }
    };
    loadPatients();
  }, []);

  useEffect(() => {
    if (consultationToEdit) {
      setForm({
        _id: consultationToEdit._id || "",
        paciente: consultationToEdit.paciente?._id || consultationToEdit.paciente || "", // Handle populated or raw ObjectId
        sistolica: consultationToEdit.sistolica || "",
        diastolica: consultationToEdit.diastolica || "",
        frecuenciaCardiaca: consultationToEdit.frecuenciaCardiaca || "",
        saturacionOxigeno: consultationToEdit.saturacionOxigeno || "",
        temperatura: consultationToEdit.temperatura || "",
        motivo: consultationToEdit.motivo || "",
        fecha: consultationToEdit.fecha ? consultationToEdit.fecha.slice(0, 10) : "",
      });
      const patient = patients.find((p) => p._id === (consultationToEdit.paciente?._id || consultationToEdit.paciente));
      setSelectedPatient(patient || null);
    } else {
      resetForm();
    }
  }, [consultationToEdit, patients]);

  const handlePatientChange = (event) => {
    const patientId = event.target.value;
    if (patientId === "") {
      setSelectedPatient(null);
      setForm({ ...form, paciente: "" });
      return;
    }
    const patient = patients.find((p) => p._id === patientId);
    setSelectedPatient(patient);
    setForm({ ...form, paciente: patient ? patient._id : "" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const consultationData = {
        paciente: form.paciente, // Send ObjectId
        sistolica: form.sistolica,
        diastolica: form.diastolica,
        frecuenciaCardiaca: form.frecuenciaCardiaca,
        saturacionOxigeno: form.saturacionOxigeno,
        temperatura: form.temperatura,
        motivo: form.motivo,
        fecha: form.fecha,
      };

      if (form._id) {
        await updateConsultation(form._id, consultationData);
        toast.success("Consulta actualizada exitosamente");
      } else {
        await createConsultation(consultationData); // Doctor is set by default in the backend
        toast.success("Consulta registrada exitosamente");
      }
      onConsultationAdded();
      resetForm();
    } catch (error) {
      toast.error(form._id ? "Error al actualizar la consulta" : "Error al registrar la consulta");
    }
  };

  const resetForm = () => {
    setForm({
      _id: "",
      paciente: "",
      sistolica: "",
      diastolica: "",
      frecuenciaCardiaca: "",
      saturacionOxigeno: "",
      temperatura: "",
      motivo: "",
      fecha: "",
    });
    setSelectedPatient(null);
  };

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">
            {form._id ? "Editar Consulta" : "Registrar Consulta"}
          </h6>
          <div className="flex gap-2">
            {form._id && (
              <button
                className="bg-blueGray-800 text-white font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                type="button"
                onClick={resetForm}
              >
                Cancelar Edición
              </button>
            )}
            <button
              className="bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
              type="submit"
              onClick={handleSubmit}
            >
              Guardar
            </button>
          </div>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form onSubmit={handleSubmit}>
          <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
            Información del Paciente
          </h6>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Paciente
                </label>
                <select
                  name="paciente"
                  value={form.paciente}
                  onChange={handlePatientChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                >
                  <option value="">Seleccione un paciente</option>
                  {patients.map((patient) => (
                    <option key={patient._id} value={patient._id}>
                      {patient.username}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Fecha
                </label>
                <input
                  type="date"
                  name="fecha"
                  value={form.fecha}
                  onChange={handleChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
              </div>
            </div>
          </div>
          <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
            Signos Vitales
          </h6>
          <div className="flex flex-wrap">
            {[
              { label: "Sistólica", name: "sistolica", placeholder: "Sistólica (mmHg)" },
              { label: "Diastólica", name: "diastolica", placeholder: "Diastólica (mmHg)" },
              { label: "Frecuencia Cardíaca", name: "frecuenciaCardiaca", placeholder: "Latidos por minuto" },
              { label: "Temperatura", name: "temperatura", placeholder: "Temperatura (°C)" },
              { label: "Saturación de Oxígeno", name: "saturacionOxigeno", placeholder: "Saturación (%)" },
            ].map((item, index) => (
              <div key={index} className="w-full lg:w-4/12 px-4">
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    {item.label}
                  </label>
                  <input
                    type="number"
                    name={item.name}
                    value={form[item.name]}
                    onChange={handleChange}
                    placeholder={item.placeholder}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    required
                  />
                </div>
              </div>
            ))}
          </div>
          <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
            Detalles Adicionales
          </h6>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-12/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Motivo de Consulta
                </label>
                <textarea
                  name="motivo"
                  value={form.motivo}
                  onChange={handleChange}
                  placeholder="Motivo de consulta"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  rows="4"
                  required
                ></textarea>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}