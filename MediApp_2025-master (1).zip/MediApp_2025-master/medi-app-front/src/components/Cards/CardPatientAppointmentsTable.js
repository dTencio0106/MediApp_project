// medi-app-front/src/components/Cards/CardPatientAppointmentsTable.js
import React from "react";
import moment from "moment";
import DynamicTable from "../utils/DynamicTable";

export default function CardPatientAppointmentsTable({ appointments }) {
  const columns = [
    {
      field: "titulo",
      header: "Título",
    },
    {
      field: "descripcion",
      header: "Descripción",
      body: (rowData) => (
        <div style={{ whiteSpace: "pre-wrap" }}>{rowData.descripcion}</div>
      ),
      style: {
        maxWidth: "300px",
        whiteSpace: "pre-wrap",
        wordBreak: "break-word",
      },
    },
    {
      field: "fechaHora",
      header: "Fecha",
      body: (rowData) => moment(rowData.fechaHora).format("YYYY-MM-DD"),
    },
    {
      field: "fechaHora",
      header: "Hora",
      body: (rowData) => moment(rowData.fechaHora).format("hh:mm A"),
    },
  ];

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">Mis Citas</h6>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <DynamicTable
          data={appointments}
          columns={columns}
          name="MisCitas"
          tableStyle={{ tableLayout: "auto" }}
        />
      </div>
    </div>
  );
}