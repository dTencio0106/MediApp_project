import React, { useState } from "react";
import { deleteAppointment } from "../../api/appointments";
import toast, { Toaster } from "react-hot-toast";
import moment from "moment";
import Swal from "sweetalert2";
import DynamicTable from "../utils/DynamicTable";

export default function CardAppointmentsTable({ appointments, onDelete, onEdit }) {
  const [selectedRow, setSelectedRow] = useState(null);

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Estás seguro?",
      text: "¿Deseas cancelar esta cita?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Sí, cancelar",
      cancelButtonText: "No",
    });

    if (result.isConfirmed) {
      try {
        await deleteAppointment(id);
        onDelete();
        toast.success("Cita cancelada exitosamente");
      } catch (error) {
        toast.error("Error al eliminar la cita");
      }
    }
  };

  const handleEdit = (appointment) => {
    onEdit(appointment);
  };

  const columns = [
    { field: "titulo", header: "Título" },
    {
      field: "descripcion",
      header: "Descripción",
      body: (rowData) => (
        <div style={{ whiteSpace: "pre-wrap" }}>{rowData.descripcion}</div>
      ),
      style: {
        maxWidth: "300px",
        whiteSpace: "pre-wrap",
        wordBreak: "break-word",
      },
    },
    {
      field: "fechaHora",
      header: "Fecha",
      body: (rowData) => moment(rowData.fechaHora).format("YYYY-MM-DD"),
    },
    {
      field: "fechaHora",
      header: "Hora",
      body: (rowData) => moment(rowData.fechaHora).format("hh:mm A"),
    },
    {
      field: "paciente.username",
      header: "Paciente",
      body: (rowData) => rowData.paciente?.username || "N/A",
    },
    {
      field: "",
      header: "Acción",
      body: (rowData) => (
        <div className="flex gap-2">
          <button
            onClick={() => handleEdit(rowData)}
            className="bg-blueGray-800 text-white font-bold py-2 px-4 rounded"
          >
            Editar
          </button>
          <button
            onClick={() => handleDelete(rowData._id)}
            className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
          >
            Cancelar
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <h6 className="text-blueGray-700 text-xl font-bold">Citas Agendadas</h6>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <DynamicTable
          data={appointments}
          columns={columns}
          name="CitasAgendadas"
          selection={selectedRow}
          onSelectionChange={(e) => setSelectedRow(e.value)}
          selectionMode="single"
          tableStyle={{ tableLayout: "auto" }}
        />
      </div>
    </div>
  );
}