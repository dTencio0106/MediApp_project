import React, { useState, useEffect } from "react";
import { createMedicalRecipe, updateMedicalRecipe } from "../../api/recipes";
import { getPatients } from "../../api/patients"; // Import from appointmentService
import toast, { Toaster } from "react-hot-toast";

export default function CardMedicalRecipe({ onRecipeAdded, recipeToEdit, onCancelEdit }) {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [form, setForm] = useState({
    _id: "",
    paciente: "",
    fecha: "",
    medicamentos: "",
    correo: "",
    cedula: "",
  });
  const [formErrors, setFormErrors] = useState({});
  const [patients, setPatients] = useState([]);

  // Load patients and map their data, including cedula
  useEffect(() => {
    const loadPatients = async () => {
      try {
        const data = await getPatients();
        const patientOptions = data.map((patient) => ({
          id: patient._id,
          nombreCompleto: patient.username, // Adjust if your model uses a different field
          correo: patient.email,
          cedula: patient.cedula
        }));
        setPatients(patientOptions);
      } catch (error) {
        toast.error("Error al cargar los pacientes");
      }
    };
    loadPatients();
  }, []);

  // Populate form when editing an existing recipe
  useEffect(() => {
    if (recipeToEdit) {
      setForm({
        _id: recipeToEdit._id || "",
        paciente: recipeToEdit.paciente || "",
        fecha: recipeToEdit.fecha ? recipeToEdit.fecha.slice(0, 10) : "",
        medicamentos: recipeToEdit.medicamentos || "",
        correo: recipeToEdit.correo || "",
        cedula: recipeToEdit.cedula || "",
      });
      const patient = patients.find((p) => p.cedula === recipeToEdit.cedula);
      setSelectedPatient(patient || null);
    }
  }, [recipeToEdit, patients]);

  // Handle patient selection using cedula
  const handlePatientChange = (event) => {
    const cedula = event.target.value;
    if (cedula === "") {
      setSelectedPatient(null);
      setForm({
        ...form,
        paciente: "",
        correo: "",
        cedula: "",
      });
      return;
    }
    const patient = patients.find((p) => p.cedula === cedula);
    setSelectedPatient(patient);
    setForm({
      ...form,
      paciente: patient ? patient.nombreCompleto : "",
      correo: patient ? patient.correo : "",
      cedula: patient ? patient.cedula : "",
    });
  };

  // Handle other form field changes
  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm({
      ...form,
      [name]: value,
    });
    setFormErrors({ ...formErrors, [name]: "" });
  };

  // Validate form fields
  const validateForm = () => {
    const errors = {};
    if (!form.fecha) {
      errors.fecha = "La fecha es obligatoria";
    }
    if (!form.medicamentos.trim()) {
      errors.medicamentos = "Los medicamentos son obligatorios";
    } else if (form.medicamentos.length < 10) {
      errors.medicamentos = "Debe tener al menos 10 caracteres";
    } else if (form.medicamentos.length > 500) {
      errors.medicamentos = "No puede exceder los 500 caracteres";
    }
    if (!form.paciente) {
      errors.paciente = "El paciente es obligatorio";
    }
    return errors;
  };

  // Submit form data
  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    try {
      if (form._id) {
        await updateMedicalRecipe(form._id, {
          paciente: form.paciente,
          fecha: form.fecha,
          medicamentos: form.medicamentos,
          correo: form.correo,
          cedula: form.cedula,
        });
        toast.success("Receta médica actualizada exitosamente");
      } else {
        await createMedicalRecipe(form);
        toast.success("Receta médica creada exitosamente");
      }
      setForm({
        _id: "",
        paciente: "",
        fecha: "",
        medicamentos: "",
        correo: "",
        cedula: "",
      });
      setFormErrors({});
      setSelectedPatient(null);
      onRecipeAdded();
    } catch (error) {
      toast.error(form._id ? "Error al actualizar la receta médica" : "Error al crear la receta médica");
    }
  };

  // Cancel editing
  const handleCancelEdit = () => {
    setForm({
      _id: "",
      paciente: "",
      fecha: "",
      medicamentos: "",
      correo: "",
      cedula: "",
    });
    setSelectedPatient(null);
    setFormErrors({});
    onCancelEdit();
  };

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">
            {form._id ? "Editar Receta Médica" : "Agregar Receta Médica"}
          </h6>
          <div className="flex gap-2">
            {form._id && (
              <button
                className="bg-blueGray-800 text-white font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                type="button"
                onClick={handleCancelEdit}
              >
                Cancelar Edición
              </button>
            )}
            <button
              className="bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
              type="button"
              onClick={handleSubmit}
            >
              Guardar
            </button>
          </div>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form onSubmit={handleSubmit}>
          <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
            Información de la Receta
          </h6>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Nombre del Paciente
                </label>
                <select
                  name="paciente"
                  value={form.cedula}
                  onChange={handlePatientChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                >
                  <option value="">Seleccione un paciente</option>
                  {patients.map((patient) => (
                    <option key={patient.cedula} value={patient.cedula}>
                      {patient.nombreCompleto}
                    </option>
                  ))}
                </select>
                {formErrors.paciente && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.paciente}</p>
                )}
              </div>
            </div>
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Fecha
                </label>
                <input
                  type="date"
                  name="fecha"
                  value={form.fecha}
                  onChange={handleChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
                {formErrors.fecha && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.fecha}</p>
                )}
              </div>
            </div>
            <div className="w-full px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Correo del Paciente
                </label>
                <input
                  type="email"
                  name="correo"
                  value={form.correo}
                  onChange={handleChange}
                  placeholder="Correo Electrónico"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  disabled
                />
              </div>
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Cédula del Paciente
                </label>
                <input
                  type="text"
                  name="cedula"
                  value={form.cedula}
                  onChange={handleChange}
                  placeholder="Cédula de paciente"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  disabled
                />
              </div>
            </div>
            <div className="w-full px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Medicamentos
                </label>
                <textarea
                  name="medicamentos"
                  value={form.medicamentos}
                  onChange={handleChange}
                  placeholder="Escriba los medicamentos y las indicaciones (mínimo 10 caracteres, máximo 500)"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  rows="4"
                  required
                  minLength={10}
                  maxLength={500}
                ></textarea>
                {formErrors.medicamentos && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.medicamentos}</p>
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}