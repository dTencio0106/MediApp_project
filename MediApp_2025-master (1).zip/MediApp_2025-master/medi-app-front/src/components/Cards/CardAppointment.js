// medi-app-front/src/components/Cards/CardAppointment.js
import React, { useState, useEffect } from "react";
import { createAppointment, updateAppointment } from "../../api/appointments";
import { getPatients } from "../../api/patients";
import { getUserInfo } from "../../api/authv2";
import toast, { Toaster } from "react-hot-toast";
import moment from "moment";

export default function CardAppointment({ onAppointmentAdded, appointmentToEdit, onCancelEdit }) {
  const [form, setForm] = useState({ _id: "", titulo: "", fechaHora: "", descripcion: "", paciente: "" });
  const [loading, setLoading] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [patients, setPatients] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const fetchUserAndPatients = async () => {
      try {
        const userData = await getUserInfo();
        setCurrentUser(userData.user);

        if (userData.user.role === "admin") {
          const patientsData = await getPatients();
          setPatients(patientsData);
        } else {
          setForm((prev) => ({ ...prev, paciente: userData.user.id }));
        }
      } catch (error) {
        toast.error("Error al cargar datos del usuario o pacientes");
      }
    };
    fetchUserAndPatients();
  }, []);

  useEffect(() => {
    if (appointmentToEdit) {
      console.log("appointmentToEdit.fechaHora:", appointmentToEdit.fechaHora); // Debug: Log incoming UTC date
      const localFechaHora = appointmentToEdit.fechaHora
        ? moment.utc(appointmentToEdit.fechaHora).local().format("YYYY-MM-DDTHH:mm")
        : "";
      console.log("Converted localFechaHora:", localFechaHora); // Debug: Log converted local date
      setForm({
        _id: appointmentToEdit._id || "",
        titulo: appointmentToEdit.titulo || "",
        fechaHora: localFechaHora,
        descripcion: appointmentToEdit.descripcion || "",
        paciente: appointmentToEdit.paciente?._id || "",
      });
    } else {
      resetForm();
    }
  }, [appointmentToEdit, currentUser]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
    setFormErrors({ ...formErrors, [name]: "" });
  };

  const validateForm = () => {
    let errors = {};
    if (!form.titulo.trim()) errors.titulo = "El título es obligatorio";
    if (!form.fechaHora.trim()) errors.fechaHora = "La fecha y hora es obligatoria";
    if (!form.descripcion.trim()) errors.descripcion = "La descripción es obligatoria";
    if (!form.paciente && currentUser?.role === "admin") errors.paciente = "El paciente es obligatorio";
    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    setLoading(true);
    try {
      // Convert local fechaHora to UTC for backend
      const utcFechaHora = moment(form.fechaHora).utc().toISOString();
      console.log("Submitted utcFechaHora:", utcFechaHora); // Debug: Log UTC date sent to backend
      const appointmentData = {
        titulo: form.titulo,
        fechaHora: utcFechaHora,
        descripcion: form.descripcion,
        paciente: form.paciente || currentUser.id,
      };

      if (form._id) {
        await updateAppointment(form._id, appointmentData);
        toast.success("Cita actualizada exitosamente");
      } else {
        await createAppointment(appointmentData);
        toast.success("Cita creada exitosamente");
      }
      // Only call onAppointmentAdded if it exists
      if (onAppointmentAdded) {
        onAppointmentAdded();
      }
      resetForm();
    } catch (error) {
      toast.error(error.message || (form._id ? "Error al actualizar la cita" : "Error al crear la cita"));
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setForm({
      _id: "",
      titulo: "",
      fechaHora: "",
      descripcion: "",
      paciente: currentUser?.role === "patient" ? currentUser.id : "",
    });
    setFormErrors({});
  };

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">
            {form._id ? "Editar Cita" : "Agregar Cita"}
          </h6>
          <div className="flex gap-2">
            {form._id && (
              <button
                className="bg-blueGray-800 text-white font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                type="button"
                onClick={() => {
                  resetForm();
                  if (onCancelEdit) {
                    onCancelEdit();
                  }
                }}
              >
                Cancelar Edición
              </button>
            )}
          </div>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form onSubmit={handleSubmit}>
          <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
            Información de la Cita
          </h6>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Título
                </label>
                <input
                  type="text"
                  name="titulo"
                  value={form.titulo}
                  onChange={handleChange}
                  placeholder="Título"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                />
                {formErrors.titulo && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.titulo}</p>
                )}
              </div>
            </div>
            <div className="w-full lg:w-6/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Fecha y Hora
                </label>
                <input
                  type="datetime-local"
                  name="fechaHora"
                  value={form.fechaHora}
                  onChange={handleChange}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                />
                {formErrors.fechaHora && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.fechaHora}</p>
                )}
              </div>
            </div>
            {currentUser?.role === "admin" && (
              <div className="w-full lg:w-6/12 px-4">
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                    Paciente
                  </label>
                  <select
                    name="paciente"
                    value={form.paciente}
                    onChange={handleChange}
                    className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  >
                    <option value="">Seleccione un paciente</option>
                    {patients.map((patient) => (
                      <option key={patient._id} value={patient._id}>
                        {patient.username} ({patient.email})
                      </option>
                    ))}
                  </select>
                  {formErrors.paciente && (
                    <p className="text-red-500 text-xs mt-1">{formErrors.paciente}</p>
                  )}
                </div>
              </div>
            )}
            <div className="w-full lg:w-12/12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                  Descripción
                </label>
                <textarea
                  name="descripcion"
                  value={form.descripcion}
                  onChange={handleChange}
                  placeholder="Descripción"
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  rows="4"
                ></textarea>
                {formErrors.descripcion && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.descripcion}</p>
                )}
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-6">
            <button
              type="submit"
              className="bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-xs px-6 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none ease-linear transition-all duration-150"
              disabled={loading}
            >
              {loading ? "Guardando..." : form._id ? "Actualizar Cita" : "Agendar Cita"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}