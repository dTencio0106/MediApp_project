import React, { useState } from "react";
import { deleteMedicalRecipe } from "../../api/recipes";
import toast, { Toaster } from "react-hot-toast";
import Swal from "sweetalert2";
import DynamicTable from "../utils/DynamicTable";

export default function CardMedicalRecipesTable({ recipes, onDelete, onEdit }) {
  const [selectedRow, setSelectedRow] = useState(null);

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Estás seguro?",
      text: "¿Deseas eliminar esta receta?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "No",
    });

    if (result.isConfirmed) {
      try {
        await deleteMedicalRecipe(id);
        onDelete(); // Refresh table after deletion
        toast.success("Receta eliminada exitosamente");
      } catch (error) {
        toast.error("Error al eliminar la receta");
      }
    }
  };

  const handleEdit = (recipe) => {
    onEdit(recipe); // Pass the selected recipe to the parent for editing
  };

  const columns = [
    { field: "paciente", header: "Paciente" },
    { field: "fecha", header: "Fecha", body: (rowData) => rowData.fecha.slice(0, 10) },
    {
      field: "medicamentos",
      header: "Medicamentos",
      body: (rowData) => (
        <div style={{ whiteSpace: "pre-wrap" }}>
          {rowData.medicamentos}
        </div>
      ),
      style: {
        maxWidth: "300px", // Set a reasonable max width for the column
        whiteSpace: "pre-wrap", // Allow text to wrap while preserving line breaks
        wordBreak: "break-word", // Break long words if necessary
      },
    },
    {
      field: "",
      header: "Acción",
      body: (rowData) => (
        <div className="flex gap-2">
          <button
            onClick={() => handleEdit(rowData)}
            className="bg-blueGray-800 text-white font-bold py-2 px-4 rounded"
          >
            Editar
          </button>
          <button
            onClick={() => handleDelete(rowData._id)}
            className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
          >
            Cancelar
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">Recetas Médicas</h6>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <DynamicTable
          data={recipes}
          columns={columns}
          name="RecetasMedicas"
          selection={selectedRow}
          onSelectionChange={(e) => setSelectedRow(e.value)} // Enable row selection
          selectionMode="single" // Allow single row selection
          tableStyle={{ tableLayout: "auto" }} // Ensure table adjusts to content
        />
      </div>
    </div>
  );
}