import React, { useState } from "react";
import { deleteConsultation } from "../../api/consultations";
import toast, { Toaster } from "react-hot-toast";
import Swal from "sweetalert2";
import DynamicTable from "../utils/DynamicTable";

export default function CardConsultationsTable({ consultations, onDelete, onEdit }) {
  const [selectedRow, setSelectedRow] = useState(null);

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Estás seguro?",
      text: "¿Deseas eliminar esta consulta?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "No",
    });

    if (result.isConfirmed) {
      try {
        await deleteConsultation(id);
        onDelete();
        toast.success("Consulta eliminada exitosamente");
      } catch (error) {
        toast.error("Error al eliminar la consulta");
      }
    }
  };

  const handleEdit = (consultation) => {
    onEdit(consultation);
  };

  const columns = [
    {
      field: "paciente.username",
      header: "Paciente",
      body: (rowData) => rowData.paciente?.username || "N/A", // Display username from populated paciente
    },
    { field: "doctor", header: "Doctor" },
    { field: "fecha", header: "Fecha", body: (rowData) => rowData.fecha.slice(0, 10) },
    {
      field: "motivo",
      header: "Motivo",
      body: (rowData) => (
        <div style={{ whiteSpace: "pre-wrap" }}>{rowData.motivo}</div>
      ),
      style: {
        maxWidth: "300px",
        whiteSpace: "pre-wrap",
        wordBreak: "break-word",
      },
    },
    {
      field: "",
      header: "Acción",
      body: (rowData) => (
        <div className="flex gap-2">
          <button
            onClick={() => handleEdit(rowData)}
            className="bg-blueGray-800 text-white font-bold py-2 px-4 rounded"
          >
            Editar
          </button>
          <button
            onClick={() => handleDelete(rowData._id)}
            className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
          >
            Cancelar
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <Toaster position="top-right" reverseOrder={false} />
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">Consultas Registradas</h6>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <DynamicTable
          data={consultations}
          columns={columns}
          name="ConsultasRegistradas"
          selection={selectedRow}
          onSelectionChange={(e) => setSelectedRow(e.value)}
          selectionMode="single"
          tableStyle={{ tableLayout: "auto" }}
        />
      </div>
    </div>
  );
}