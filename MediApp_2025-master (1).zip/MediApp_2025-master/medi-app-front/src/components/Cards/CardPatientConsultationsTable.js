import React from "react";
import DynamicTable from "../utils/DynamicTable";

export default function CardPatientConsultationsTable({ consultations }) {
  const columns = [
    {
      field: "doctor",
      header: "Doctor",
    },
    {
      field: "fecha",
      header: "Fecha",
      body: (rowData) => rowData.fecha.slice(0, 10),
    },
    {
      field: "motivo",
      header: "Motivo",
      body: (rowData) => (
        <div style={{ whiteSpace: "pre-wrap" }}>{rowData.motivo}</div>
      ),
      style: {
        maxWidth: "300px",
        whiteSpace: "pre-wrap",
        wordBreak: "break-word",
      },
    },
    {
      field: "sistolica",
      header: "Sistólica",
      body: (rowData) => `${rowData.sistolica} mmHg`,
    },
    {
      field: "diastolica",
      header: "Diastólica",
      body: (rowData) => `${rowData.diastolica} mmHg`,
    },
    {
      field: "frecuenciaCardiaca",
      header: "Frecuencia Cardiaca",
      body: (rowData) => `${rowData.frecuenciaCardiaca} lat/min`,
    },
    {
      field: "saturacionOxigeno",
      header: "Saturación Oxígeno",
      body: (rowData) => `${rowData.saturacionOxigeno}%`,
    },
    {
      field: "temperatura",
      header: "Temperatura",
      body: (rowData) => `${rowData.temperatura}°C`,
    },
  ];

  return (
    <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
      <div className="rounded-t bg-white mb-0 px-6 py-6">
        <div className="text-center flex justify-between">
          <h6 className="text-blueGray-700 text-xl font-bold">Mis Consultas</h6>
        </div>
      </div>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <DynamicTable
          data={consultations}
          columns={columns}
          name="MisConsultas"
          tableStyle={{ tableLayout: "auto" }}
        />
      </div>
    </div>
  );
}