/* eslint-disable */
import React from "react";
import { Link } from "react-router-dom";

export default function Navbar(props) {
  const [navbarOpen, setNavbarOpen] = React.useState(false);

  return (
    <>
      <nav className="top-0 fixed z-50 w-full flex flex-wrap items-center justify-between px-2 py-3 navbar-expand-lg bg-gray-900">
        <div className="container px-4 mx-auto flex flex-wrap items-center justify-between">
          {/* Brand Logo */}
          <div className="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start">
            <Link
              className="text-white text-sm font-bold leading-relaxed inline-block mr-4 py-2 whitespace-nowrap uppercase"
              to="/"
            >
              Dr. Marlon Jiménez
            </Link>
            {/* Hamburger Button */}
            <button
              className="cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none text-white"
              type="button"
              onClick={() => setNavbarOpen(!navbarOpen)}
              aria-label="Toggle navigation"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>

          {/* Navigation Menu */}
          <div
            className={`lg:flex flex-grow items-center transition-all duration-300 ease-in-out ${
              navbarOpen
                ? "block w-full lg:w-auto"
                : "hidden w-0 lg:w-auto"
            } lg:bg-transparent`}
          >
            <ul className="flex flex-col lg:flex-row list-none lg:ml-auto w-full lg:w-auto">
              <li className="nav-item w-full lg:w-auto">
                <Link
                  to="/auth"
                  className="block px-4 py-2 text-sm font-semibold text-white bg-blue-500 hover:bg-blue-700 rounded-md shadow lg:inline-block w-full lg:w-auto text-center"
                  onClick={() => setNavbarOpen(false)} // Close menu on click (mobile)
                >
                  Iniciar Sesión
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
}