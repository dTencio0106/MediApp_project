import React from "react";
import { useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

export default function Navbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/auth/login");
  };

  return (
    <>
      {/* Navbar */}
      <nav className="absolute top-0 left-0 w-full z-10 bg-transparent md:flex-row md:flex-nowrap md:justify-start flex items-center p-4">
        <div className="w-full mx-auto items-center flex justify-end md:flex-nowrap flex-wrap md:px-10 px-4">
          <ul className="flex-col md:flex-row list-none items-center hidden md:flex">
            <button
              onClick={handleLogout}
              className="bg-red-500 text-white font-bold uppercase text-xs px-6 py-2 rounded shadow hover:bg-red-600 hover:shadow-md outline-none focus:outline-none ease-linear transition-all duration-150"
            >
              <i className="fas fa-sign-out-alt mr-2"></i>
              Cerrar Sesión
            </button>
          </ul>
        </div>
      </nav>
    </>
  );
}