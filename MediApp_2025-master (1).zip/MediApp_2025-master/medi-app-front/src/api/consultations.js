const API_URL = process.env.REACT_APP_API_URL;

const getAuthToken = () => {
  const token = localStorage.getItem("token");
  return token;
};

export const getConsultations = async () => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/consultas`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al obtener las consultas");
  return response.json();
};

export const createConsultation = async (consultation) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/consultas`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify(consultation),
  });
  if (!response.ok) throw new Error("Error al crear la consulta");
  return response.json();
};

export const updateConsultation = async (id, consultation) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/consultas/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(consultation),
  });
  if (!response.ok) throw new Error("Error al actualizar la consulta");
  return response.json();
};

export const deleteConsultation = async (id) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/consultas/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al eliminar la consulta");
  return response.json();
};