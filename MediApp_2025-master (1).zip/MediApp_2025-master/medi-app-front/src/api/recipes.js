// src/services/medicalRecipesService.js
const API_URL = process.env.REACT_APP_API_URL;

const getAuthToken = () => {
  const token = localStorage.getItem("token");
  return token;
};

// Obtener todas las recetas
export const getMedicalRecipes = async () => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/recetas`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      Authorization: `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al obtener las recetas médicas");
  return response.json();
};

// Crear una receta
export const createMedicalRecipe = async (recipe) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/recetas`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(recipe),
  });
  if (!response.ok) throw new Error("Error al crear la receta médica");
  return response.json();
};

// Actualizar una receta
export const updateMedicalRecipe = async (id, recipe) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/recetas/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(recipe),
  });
  if (!response.ok) throw new Error("Error al actualizar la receta médica");
  return response.json();
};

// Eliminar una receta
export const deleteMedicalRecipe = async (id) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/recetas/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al eliminar la receta médica");
  return response.json();
};