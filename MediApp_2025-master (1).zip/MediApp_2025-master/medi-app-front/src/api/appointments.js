// medi-app-front/src/api/appointments.js
const API_URL = process.env.REACT_APP_API_URL + "/citas";

const getAuthToken = () => {
  const token = localStorage.getItem("token");
  console.log("Token en localStorage para citas:", token);
  return token;
};

export const getAppointments = async () => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error al obtener las citas");
  }
  return response.json();
};

export const getPatientAppointments = async () => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/patient`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error al obtener tus citas");
  }
  return response.json();
};

export const createAppointment = async (appointment) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify(appointment),
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error al crear la cita");
  }
  return response.json();
};

export const updateAppointment = async (id, appointment) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
    body: JSON.stringify(appointment),
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error al actualizar la cita");
  }
  return response.json();
};

export const deleteAppointment = async (id) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/${id}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Error al eliminar la cita");
  }
  return response.json();
};