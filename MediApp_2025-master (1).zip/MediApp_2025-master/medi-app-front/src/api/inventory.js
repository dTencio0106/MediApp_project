const API_URL = process.env.REACT_APP_API_URL;

export const createInventory = async (data) => {
  const response = await fetch(`${API_URL}/inventario`, {
    method: 'POST',
    body: data, // FormData, no Content-Type header needed (browser sets it)
  });
  if (!response.ok) throw new Error('Error al crear el inventario');
  return response.json();
};

export const getInventory = async () => {
  const response = await fetch(`${API_URL}/inventario`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
    },
  });
  if (!response.ok) throw new Error('Error al obtener los medicamentos');
  return response.json();
};

export const updateInventory = async (id, data) => {
  const response = await fetch(`${API_URL}/inventario/${id}`, {
    method: 'PUT',
    body: data, // FormData, no Content-Type header needed (browser sets it)
  });
  if (!response.ok) throw new Error('Error al actualizar el medicamento');
  return response.json();
};

export const deleteInventory = async (id) => {
  const response = await fetch(`${API_URL}/inventario/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Error al eliminar el inventario');
  return response.json();
};