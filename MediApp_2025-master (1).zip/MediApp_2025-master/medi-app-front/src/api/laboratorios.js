const API_URL = process.env.REACT_APP_API_URL;

const getAuthToken = () => {
  const token = localStorage.getItem("token");
  return token;
};

// Obtener todos los laboratorios
export const getLaboratorios = async () => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/laboratorio`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "69420",
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al obtener los laboratorios");
  return response.json();
};

// Crear un laboratorio
export const createLaboratorio = async (formData) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/laboratorio`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
    },
    body: formData,
  });
  if (!response.ok) throw new Error("Error al crear el laboratorio");
  return response.json();
};

// Eliminar un laboratorio
export const deleteLaboratorio = async (id) => {
  const token = getAuthToken();
  if (!token) throw new Error("No se encontró el token de autenticación");

  const response = await fetch(`${API_URL}/laboratorio/${id}`, {
    method: "DELETE",
    headers: {
      "Authorization": `Bearer ${token}`,
    },
  });
  if (!response.ok) throw new Error("Error al eliminar el laboratorio");
  return response.json();
};