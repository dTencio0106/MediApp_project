const getAuthToken = () => {
    const token = localStorage.getItem("token");
    console.log("Token en localStorage para citas:", token);
    return token;
  };
  
export const getPatients = async () => {
    const token = getAuthToken();
    if (!token) throw new Error("No se encontró el token de autenticación");
  
    const response = await fetch(`${process.env.REACT_APP_API_URL}/users/patients`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "69420",
        "Authorization": `Bearer ${token}`,
      },
    });
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Error al obtener los pacientes");
    }
    return response.json();
  };