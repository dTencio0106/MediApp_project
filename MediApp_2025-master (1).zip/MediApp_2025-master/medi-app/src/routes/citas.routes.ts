// backend/src/routes/citas.route.ts
import { Router } from "express";
import { verifyToken } from "../middlewares/auth.middleware";
import { createCita, getCitas, getPatientCitas, updateCita, deleteCita } from "../controllers/citas.controller";

const router = Router();

router.post("/", verifyToken, createCita);
router.get("/", verifyToken, getCitas);
router.get("/patient", verifyToken, getPatientCitas);
router.put("/:id", verifyToken, updateCita);
router.delete("/:id", verifyToken, deleteCita);

export default router;