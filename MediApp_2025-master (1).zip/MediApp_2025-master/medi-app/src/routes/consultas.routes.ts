import { Router } from "express";
import { createConsulta, getConsultas, deleteConsulta, updateConsulta } from "../controllers/consultas.controller";
import { verifyToken } from "../middlewares/auth.middleware";

const router = Router();

router.post("/", verifyToken, createConsulta);
router.get("/", verifyToken, getConsultas);
router.put("/:id", verifyToken, updateConsulta);
router.delete("/:id", verifyToken, deleteConsulta);

export default router;