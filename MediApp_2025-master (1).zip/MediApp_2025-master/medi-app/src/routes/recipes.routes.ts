// src/routes/recipes.ts
import { Router } from "express";
import { createRecipe, getRecipes, deleteRecipe, updateRecipe } from "../controllers/recipes.controller";
import { verifyToken } from "../middlewares/auth.middleware";

const router = Router();

router.post("/", verifyToken, createRecipe); // Crear una nueva receta
router.get("/", verifyToken, getRecipes); // Obtener todas las recetas
router.put("/:id", verifyToken, updateRecipe); // Actualizar una receta por ID
router.delete("/:id", verifyToken, deleteRecipe); // Eliminar una receta por ID

export default router;