import { Router, Request as ExpressRequest, Response as ExpressResponse } from 'express';
import { 
  createLaboratorio, 
  getLaboratorios, 
  deleteLaboratorio 
} from '../controllers/laboratorio.controller';
import upload from '../utils/upload';
import mongoose from 'mongoose';
import path from 'path';

// Define custom Request and Response types with params
interface CustomRequest extends ExpressRequest {
  params: { filename: string };
}

const router: Router = Router();

// POST - Create new laboratorio with file upload
router.post('/', upload.array('archivos'), createLaboratorio);

// GET - Get all laboratorios
router.get('/', getLaboratorios);

// DELETE - Delete a laboratorio by ID
router.delete('/:id', deleteLaboratorio);

// GET - Serve a file from GridFS by filename
router.get('/file/:filename', async (req: CustomRequest, res: ExpressResponse) => {
  try {
    const db = mongoose.connection.db;
    if (!db) {
      throw new Error('MongoDB connection is not established');
    }

    const gridFSBucket = new mongoose.mongo.GridFSBucket(db, {
      bucketName: 'uploads'
    });

    const files = await gridFSBucket.find({ filename: req.params.filename }).toArray();
    if (!files || files.length === 0) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    const file = files[0];
    const downloadStream = gridFSBucket.openDownloadStreamByName(req.params.filename);

    const ext = path.extname(file.filename).toLowerCase();
    let contentType = 'application/octet-stream';
    if (ext === '.pdf') {
      contentType = 'application/pdf';
    } else if (ext === '.png' || ext === '.jpg' || ext === '.jpeg') {
      contentType = `image/${ext.slice(1)}`;
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`); // Always download

    downloadStream.pipe(res);

    downloadStream.on('error', (err) => {
      res.status(500).json({ error: 'Error al transmitir el archivo', details: err.message });
    });
  } catch (error) {
    const err = error as Error;
    res.status(500).json({ error: 'Error al obtener el archivo', details: err.message });
  }
});


export default router;