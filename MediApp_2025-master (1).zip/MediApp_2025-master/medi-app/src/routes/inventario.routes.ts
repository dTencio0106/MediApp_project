import { Router } from 'express';
import { createInventory, getInventory, updateInventory, deleteInventory } from '../controllers/inventario.controller';
import upload from '../utils/upload';
import mongoose from 'mongoose';
import path from 'path';

const router: Router = Router();

router.post('/', upload.single('imagen'), createInventory);
router.get('/', getInventory);
router.put('/:id', upload.single('imagen'), updateInventory);
router.delete('/:id', deleteInventory); // Add DELETE route

router.get('/file/:filename', async (req, res) => {
  try {
    const db = mongoose.connection.db;
    if (!db) {
      throw new Error('MongoDB connection is not established');
    }

    const gridFSBucket = new mongoose.mongo.GridFSBucket(db, {
      bucketName: 'uploads'
    });

    const files = await gridFSBucket.find({ filename: req.params.filename }).toArray();
    if (!files || files.length === 0) {
      return res.status(404).json({ error: 'Archivo no encontrado' });
    }

    const file = files[0];
    const downloadStream = gridFSBucket.openDownloadStreamByName(req.params.filename);

    const ext = path.extname(file.filename).toLowerCase();
    let contentType = 'application/octet-stream';
    if (ext === '.png' || ext === '.jpg' || ext === '.jpeg') {
      contentType = `image/${ext.slice(1)}`;
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `inline; filename="${file.filename}"`);

    downloadStream.pipe(res);

    downloadStream.on('error', (err) => {
      res.status(500).json({ error: 'Error al transmitir el archivo', details: err.message });
    });
  } catch (error) {
    const err = error as Error;
    res.status(500).json({ error: 'Error al obtener el archivo', details: err.message });
  }
});

export default router;