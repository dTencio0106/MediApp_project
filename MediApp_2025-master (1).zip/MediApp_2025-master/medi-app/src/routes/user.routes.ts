import { Router } from "express";
import { verifyToken } from "../middlewares/auth.middleware";
import { getPatients } from "../controllers/users.controller";

const router = Router();

router.get("/patients", verifyToken, getPatients);

export default router;