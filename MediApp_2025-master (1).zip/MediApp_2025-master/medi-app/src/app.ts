import express from "express";
import cors from "cors";
import { json, urlencoded } from "express";
import dotenv from "dotenv";
import citasRoutes from "./routes/citas.routes";
import consultasRoutes from "./routes/consultas.routes";
import recipesRoutes from "./routes/recipes.routes";
import authRoutes from "./routes/auth.routes";
import medicalFormRoutes from "./routes/medicalForm.routes"
import inventarioRoutes from './routes/inventario.routes';
import laboratorioRoutes from './routes/laboratorio.routes';
import swaggerJSDoc, { Options } from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import userRoutes from "./routes/user.routes";

const swaggerDefinition = {
  openapi: '3.0.0',
  info: {
    title: 'Express API for JSONPlaceholder',
    version: '1.0.0',
    description:
      'This is a REST API application made with Express. It retrieves data from JSONPlaceholder.',
    license: {
      name: 'Licensed Under MIT',
      url: 'https://spdx.org/licenses/MIT.html',
    },
    contact: {
      name: 'JSONPlaceholder',
      url: 'https://jsonplaceholder.typicode.com',
    },
  },
  externalDocs: {                // <<< this will add the link to your swagger page
    description: "swagger.json", // <<< link title
    url: "/swagger.json"
  },
  servers: [
    {
      url: 'http://localhost:4000/api',
      description: 'Development server',
    },
  ],
};

const options: Options = {
  swaggerDefinition,
  // Paths to files containing OpenAPI definitions
  apis: ['**/routes/*.ts'], // Assuming your route files are also converted to TypeScript
};

const swaggerSpec = swaggerJSDoc(options);

dotenv.config();

const app = express();

// Middlewares
app.use(cors());
app.use(json());
app.use(urlencoded({ extended: true }));


app.use("/api/citas", citasRoutes);
app.use("/api/consultas", consultasRoutes);
app.use("/api/recetas", recipesRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/medical-forms", medicalFormRoutes);
app.use("/api/inventario", inventarioRoutes);
app.use("/api/laboratorio", laboratorioRoutes);
app.use("/api/users", userRoutes);

// swagger
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.get('/swagger.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

// Rutas
export default app;
