// backend/src/controllers/citas.controller.ts
import { Request, Response } from "express";
import Cita, { ICita } from "../models/cita.model";
import User from "../models/user.model";
import { sendEmail } from "../services/email.service";
import moment from "moment-timezone";
import dotenv from "dotenv";
import { Types } from "mongoose";

dotenv.config();

interface AuthenticatedRequest extends Request {
  userId?: string;
}

export const createCita = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const { titulo, fechaHora, descripcion, paciente } = req.body;
    const userId = req.userId;

    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    // Determine paciente based on user role
    let pacienteId: Types.ObjectId | string = userId; // Default to logged-in user (for patients)
    if (user.role === "admin" && paciente) {
      const patientUser = await User.findOne({ _id: paciente, role: "patient" });
      if (!patientUser) {
        res.status(400).json({ message: "Paciente inválido o no encontrado" });
        return;
      }
      pacienteId = patientUser._id;
    }

    // Use UTC for internal date operations
    const currentDateTime = moment.utc();
    const appointmentDateTime = moment.utc(fechaHora);

    if (appointmentDateTime.isBefore(currentDateTime)) {
      res.status(400).json({
        message: "No se puede crear una cita en el pasado. Por favor, selecciona una fecha y hora futura.",
      });
      return;
    }

    // Convert to clinic's timezone for business hour validation and display
    const clinicTimezone = "America/Costa_Rica"; // Clinic's timezone
    const appointmentLocalTime = appointmentDateTime.clone().tz(clinicTimezone);
    const appointmentHour = appointmentLocalTime.hour();
    if (appointmentHour < 8 || appointmentHour >= 17) {
      res.status(400).json({
        message: "No se puede crear una cita fuera del horario de consulta. El horario de consulta es de 8am-5pm.",
      });
      return;
    }

    const citaExistente = await Cita.findOne({ fechaHora });
    if (citaExistente) {
      res.status(400).json({
        message: "El horario ya está ocupado. Por favor, selecciona otro horario.",
      });
      return;
    }

    const nuevaCita = new Cita({
      titulo,
      fechaHora,
      descripcion,
      paciente: pacienteId,
      creadaPor: userId,
    });
    await nuevaCita.save();

    const patient = await User.findById(pacienteId);
    if (!patient) {
      res.status(500).json({ message: "Paciente no encontrado después de crear la cita" });
      return;
    }

    // Format appointment time in clinic's timezone for email
    const formattedAppointmentTime = appointmentLocalTime.format("YYYY-MM-DD hh:mm A");

    const subject = "Cita en MediApp";
    const text = `Se ha creado una nueva cita con la siguiente información:\n\nTítulo: ${titulo}\nDescripción: ${descripcion}\nFecha y Hora: ${formattedAppointmentTime} (Horario de la Clínica)`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h1 style="color: #4CAF50; text-align: center;">Nueva Cita Creada</h1>
        <p style="font-size: 16px; color: #333;">Se ha creado una nueva cita con la siguiente información:</p>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Título:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${titulo}</td>
          </tr>
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Descripción:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${descripcion}</td>
          </tr>
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Fecha y Hora:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${formattedAppointmentTime} (Horario de la Clínica)</td>
          </tr>
        </table>
        <p style="font-size: 14px; color: #777; text-align: center; margin-top: 20px;">Gracias por usar nuestro servicio.</p>
      </div>
    `;

    await sendEmail(patient.email, subject, text, html);

    res.status(201).json({ message: "Cita creada exitosamente", data: nuevaCita });
  } catch (error) {
    res.status(500).json({ message: "Error al crear la cita", error });
  }
};

export const getCitas = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const citas = await Cita.find().populate("paciente", "username email").populate("creadaPor", "username");
    res.status(200).json(citas);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener las citas", error });
  }
};

export const getPatientCitas = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user || user.role !== "patient") {
      res.status(403).json({ message: "Acceso denegado. Solo pacientes pueden ver sus citas." });
      return;
    }

    const citas = await Cita.find({ paciente: userId }).populate("paciente", "username email").populate("creadaPor", "username");
    res.status(200).json(citas);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener tus citas", error });
  }
};

export const updateCita = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { titulo, fechaHora, descripcion, paciente } = req.body;
    const userId = req.userId;

    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    let pacienteId: Types.ObjectId | undefined;
    if (user.role === "admin" && paciente) {
      const patientUser = await User.findOne({ _id: paciente, role: "patient" });
      if (!patientUser) {
        res.status(400).json({ message: "Paciente inválido o no encontrado" });
        return;
      }
      pacienteId = patientUser._id;
    }

    const currentDateTime = moment();
    const appointmentDateTime = moment(fechaHora);

    if (appointmentDateTime.isBefore(currentDateTime)) {
      res.status(400).json({
        message: "No se puede actualizar a una cita en el pasado. Por favor, selecciona una fecha y hora futura.",
      });
      return;
    }

    const appointmentHour = appointmentDateTime.hour();
    if (appointmentHour < 8 || appointmentHour >= 17) {
      res.status(400).json({
        message: "No se puede actualizar a una cita fuera del horario de consulta. El horario de consulta es de 8am-5pm.",
      });
      return;
    }

    const citaExistente = await Cita.findOne({ fechaHora, _id: { $ne: id } });
    if (citaExistente) {
      res.status(400).json({
        message: "El horario ya está ocupado por otra cita. Por favor, selecciona otro horario.",
      });
      return;
    }

    const updateData: Partial<ICita> = { titulo, fechaHora, descripcion };
    if (pacienteId) updateData.paciente = pacienteId;

    const citaActualizada = await Cita.findByIdAndUpdate(id, updateData, { new: true });

    if (!citaActualizada) {
      res.status(404).json({ message: "Cita no encontrada" });
      return;
    }

    const patient = await User.findById(citaActualizada.paciente);
    if (!patient) {
      res.status(500).json({ message: "Paciente no encontrado después de actualizar la cita" });
      return;
    }

    const subject = "Cita Actualizada en MediApp";
    const text = `Se ha actualizado una cita con la siguiente información:\n\nTítulo: ${titulo}\nDescripción: ${descripcion}\nFecha y Hora: ${fechaHora}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h1 style="color: #4CAF50; text-align: center;">Cita Actualizada</h1>
        <p style="font-size: 16px; color: #333;">Se ha actualizado una cita con la siguiente información:</p>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Título:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${titulo}</td>
          </tr>
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Descripción:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${descripcion}</td>
          </tr>
          <tr>
            <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Fecha y Hora:</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${moment(fechaHora).format("YYYY-MM-DD hh:mm A")}</td>
          </tr>
        </table>
        <p style="font-size: 14px; color: #777; text-align: center; margin-top: 20px;">Gracias por usar nuestro servicio.</p>
      </div>
    `;

    await sendEmail(patient.email, subject, text, html);

    res.status(200).json({ message: "Cita actualizada exitosamente", data: citaActualizada });
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar la cita", error });
  }
};

export const deleteCita = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const citaEliminada = await Cita.findByIdAndDelete(id);

    if (!citaEliminada) {
      res.status(404).json({ message: "Cita no encontrada" });
      return;
    }

    res.status(200).json({ message: "Cita eliminada exitosamente" });
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar la cita", error });
  }
};