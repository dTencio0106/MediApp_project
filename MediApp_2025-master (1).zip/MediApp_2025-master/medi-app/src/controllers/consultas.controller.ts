import { Request, Response } from "express";
import Consulta, { IConsulta } from "../models/consulta.model";
import User from "../models/user.model";

// Crear una nueva consulta
export const createConsulta = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      paciente, // Now expecting an ObjectId
      sistolica,
      diastolica,
      frecuenciaCardiaca,
      saturacionOxigeno,
      temperatura,
      motivo,
      fecha,
    } = req.body;

    // Validate that paciente is a valid patient (User with role: "patient")
    const patient = await User.findOne({ _id: paciente, role: "patient" });
    if (!patient) {
      res.status(400).json({ message: "Paciente inválido o no encontrado" });
      return;
    }

    const nuevaConsulta = new Consulta({
      paciente: patient._id,
      doctor: "Marlon Jimenez",
      sistolica,
      diastolica,
      frecuenciaCardiaca,
      saturacionOxigeno,
      temperatura,
      motivo,
      fecha,
    });

    await nuevaConsulta.save();
    res.status(201).json({ message: "Consulta creada exitosamente", data: nuevaConsulta });
  } catch (error) {
    res.status(500).json({ message: "Error al crear la consulta", error });
  }
};

// Obtener todas las consultas
export const getConsultas = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = (req as any).userId; // Set by verifyToken middleware
    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    let consultas;
    if (user.role === "admin") {
      // Admins see all consultations
      consultas = await Consulta.find().populate("paciente", "username email");
    } else if (user.role === "patient") {
      // Patients see only their own consultations
      consultas = await Consulta.find({ paciente: userId }).populate("paciente", "username email");
    } else {
      res.status(403).json({ message: "Acceso denegado" });
      return;
    }

    res.status(200).json(consultas);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener las consultas", error });
  }
};

// Actualizar una consulta por ID
export const updateConsulta = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const {
      paciente, // Now expecting an ObjectId
      sistolica,
      diastolica,
      frecuenciaCardiaca,
      saturacionOxigeno,
      temperatura,
      motivo,
      fecha,
    } = req.body;

    // Validate paciente if provided
    if (paciente) {
      const patient = await User.findOne({ _id: paciente, role: "patient" });
      if (!patient) {
        res.status(400).json({ message: "Paciente inválido o no encontrado" });
        return;
      }
    }

    const updatedConsulta = await Consulta.findByIdAndUpdate(
      id,
      {
        ...(paciente && { paciente }), // Only update paciente if provided
        sistolica,
        diastolica,
        frecuenciaCardiaca,
        saturacionOxigeno,
        temperatura,
        motivo,
        fecha,
      },
      { new: true, runValidators: true }
    ).populate("paciente", "username email");

    if (!updatedConsulta) {
      res.status(404).json({ message: "Consulta no encontrada" });
      return;
    }

    res.status(200).json({ message: "Consulta actualizada exitosamente", data: updatedConsulta });
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar la consulta", error });
  }
};

// Eliminar una consulta por ID
export const deleteConsulta = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const consultaEliminada = await Consulta.findByIdAndDelete(id);

    if (!consultaEliminada) {
      res.status(404).json({ message: "Consulta no encontrada" });
      return;
    }

    res.status(200).json({ message: "Consulta eliminada exitosamente" });
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar la consulta", error });
  }
};