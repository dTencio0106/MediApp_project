import { Request, Response } from 'express';
import Inventario, { IInventario } from '../models/inventario.model';
import mongoose from 'mongoose';

export const createInventory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { nombre, descripcion, cantidad } = req.body;
    const imagen = req.file ? req.file.filename : undefined; // Get the GridFS filename

    const nuevoInventario = new Inventario({ nombre, descripcion, cantidad: parseInt(cantidad), imagen });
    await nuevoInventario.save();
    res.status(201).json(nuevoInventario);
  } catch (error) {
    res.status(500).json({ message: 'Error al crear el inventario', error });
  }
};

export const getInventory = async (req: Request, res: Response): Promise<void> => {
  try {
    const inventario = await Inventario.find();
    res.status(200).json(inventario);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener los Inventario', error });
  }
};

export const updateInventory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { nombre, descripcion, cantidad } = req.body;
    const imagen = req.file ? req.file.filename : req.body.imagen; // Use existing imagen if no new file is uploaded

    const updateData: Partial<IInventario> = {
      nombre,
      descripcion,
      cantidad: parseInt(cantidad),
    };

    if (imagen) {
      updateData.imagen = imagen;
    }

    const inventarioActualizado = await Inventario.findByIdAndUpdate(id, updateData, { new: true });
    if (!inventarioActualizado) {
      res.status(404).json({ message: 'Inventario no encontrado' });
      return;
    }
    res.status(200).json(inventarioActualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar el Inventario', error });
  }
};

export const deleteInventory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    // Find the inventory item
    const inventario = await Inventario.findById(id);
    if (!inventario) {
      res.status(404).json({ message: 'Inventario no encontrado' });
      return;
    }

    // If the inventory item has an image, delete it from GridFS
    if (inventario.imagen) {
      const db = mongoose.connection.db;
      if (!db) {
        throw new Error('MongoDB connection is not established');
      }

      const gridFSBucket = new mongoose.mongo.GridFSBucket(db, {
        bucketName: 'uploads',
      });

      const files = await gridFSBucket.find({ filename: inventario.imagen }).toArray();
      if (files && files.length > 0) {
        const fileId = files[0]._id;
        await gridFSBucket.delete(fileId);
      }
    }

    // Delete the inventory item from the database
    await Inventario.findByIdAndDelete(id);
    res.status(200).json({ message: 'Inventario eliminado exitosamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar el inventario', error });
  }
};