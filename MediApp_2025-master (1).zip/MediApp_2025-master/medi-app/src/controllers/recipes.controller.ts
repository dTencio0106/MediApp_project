import { Request, Response } from "express";
import Recipe, { IRecipe } from "../models/recipe.model";
import User from "../models/user.model";
import { sendEmail } from "../services/email.service";

// Crear una nueva receta
export const createRecipe = async (req: Request, res: Response): Promise<void> => {
  try {
    const { paciente, fecha, medicamentos, correo, cedula } = req.body;
    const userId = (req as any).userId; // Set by verifyToken middleware

    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    // Validate user
    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    // Basic validation
    if (!correo || !correo.includes("@")) {
      res.status(400).json({ message: "Correo inválido" });
      return;
    }
    if (!cedula || cedula.length < 5) {
      res.status(400).json({ message: "Cédula inválida (mínimo 5 caracteres)" });
      return;
    }
    if (!paciente || !fecha || !medicamentos) {
      res.status(400).json({ message: "Faltan campos requeridos: paciente, fecha o medicamentos" });
      return;
    }

    // If patient, ensure the recipe is created for their own email
    if (user.role === "patient" && correo !== user.email) {
      res.status(403).json({ message: "No puedes crear recetas para otro correo" });
      return;
    }

    const nuevaReceta = new Recipe({ paciente, fecha, medicamentos, correo, cedula });
    await nuevaReceta.save();

    // Enviar correo electrónico al paciente
    const subject = "Nueva Receta Médica";
    const text = `Hola ${paciente},\n\nTu receta médica ha sido generada.\n\nMedicamentos:\n${medicamentos}\n\nFecha: ${fecha}`;
    const html = `
      <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; color: #333; background-color: #f7f7f7; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
        <h2 style="text-align: center; color: #007bff;">Nueva Receta Médica</h2>
        <p>Hola ${paciente},</p>
        <p>Tu receta médica ha sido generada.</p>
        <p><strong>Medicamentos:</strong></p>
        <p>${medicamentos}</p>
        <p><strong>Fecha:</strong> ${new Date(fecha).toLocaleDateString()}</p>
      </div>
    `;

    await sendEmail(correo, subject, text, html);

    res.status(201).json({ message: "Receta médica creada y correo enviado", data: nuevaReceta });
  } catch (error: any) {
    res.status(500).json({ message: "Error al crear la receta médica", error: error.message });
  }
};

// Obtener todas las recetas
export const getRecipes = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = (req as any).userId; // Set by verifyToken middleware
    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    let recetas;
    if (user.role === "admin") {
      // Admins see all recipes
      recetas = await Recipe.find();
    } else if (user.role === "patient") {
      // Patients see only their own recipes
      recetas = await Recipe.find({ correo: user.email });
    } else {
      res.status(403).json({ message: "Acceso denegado" });
      return;
    }

    res.status(200).json(recetas);
  } catch (error: any) {
    res.status(500).json({ message: "Error al obtener las recetas médicas", error: error.message });
  }
};

// Actualizar una receta por ID
export const updateRecipe = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { paciente, fecha, medicamentos, correo, cedula } = req.body;
    const userId = (req as any).userId; // Set by verifyToken middleware

    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    // Validate user
    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    // Basic validation
    if (correo && !correo.includes("@")) {
      res.status(400).json({ message: "Correo inválido" });
      return;
    }
    if (cedula && cedula.length < 5) {
      res.status(400).json({ message: "Cédula inválida (mínimo 5 caracteres)" });
      return;
    }

    // If patient, ensure they can only update their own recipes
    const existingRecipe = await Recipe.findById(id);
    if (!existingRecipe) {
      res.status(404).json({ message: "Receta médica no encontrada" });
      return;
    }
    if (user.role === "patient" && existingRecipe.correo !== user.email) {
      res.status(403).json({ message: "No puedes actualizar recetas de otro usuario" });
      return;
    }
    if (user.role === "patient" && correo && correo !== user.email) {
      res.status(403).json({ message: "No puedes actualizar el correo a otro usuario" });
      return;
    }

    // Find and update the recipe
    const updatedRecipe = await Recipe.findByIdAndUpdate(
      id,
      { paciente, fecha, medicamentos, correo, cedula },
      { new: true, runValidators: true } // Return the updated document and run schema validators
    );

    if (!updatedRecipe) {
      res.status(404).json({ message: "Receta médica no encontrada" });
      return;
    }

    // Send email notification about the update
    const subject = "Receta Médica Actualizada";
    const text = `Hola ${paciente},\n\nTu receta médica ha sido actualizada.\n\nMedicamentos:\n${medicamentos}\n\nFecha: ${fecha}`;
    const html = `
      <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; color: #333; background-color: #f7f7f7; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
        <h2 style="text-align: center; color: #007bff;">Receta Médica Actualizada</h2>
        <p>Hola ${paciente},</p>
        <p>Tu receta médica ha sido actualizada.</p>
        <p><strong>Medicamentos:</strong></p>
        <p>${medicamentos}</p>
        <p><strong>Fecha:</strong> ${new Date(fecha).toLocaleDateString()}</p>
      </div>
    `;

    await sendEmail(correo || existingRecipe.correo, subject, text, html);

    res.status(200).json({ message: "Receta médica actualizada y correo enviado", data: updatedRecipe });
  } catch (error: any) {
    res.status(500).json({ message: "Error al actualizar la receta médica", error: error.message });
  }
};

// Eliminar una receta por ID
export const deleteRecipe = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId; // Set by verifyToken middleware

    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    // Validate user
    const user = await User.findById(userId);
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    // If patient, ensure they can only delete their own recipes
    const existingRecipe = await Recipe.findById(id);
    if (!existingRecipe) {
      res.status(404).json({ message: "Receta médica no encontrada" });
      return;
    }
    if (user.role === "patient" && existingRecipe.correo !== user.email) {
      res.status(403).json({ message: "No puedes eliminar recetas de otro usuario" });
      return;
    }

    const recetaEliminada = await Recipe.findByIdAndDelete(id);

    if (!recetaEliminada) {
      res.status(404).json({ message: "Receta médica no encontrada" });
      return;
    }

    res.status(200).json({ message: "Receta médica eliminada exitosamente" });
  } catch (error: any) {
    res.status(500).json({ message: "Error al eliminar la receta médica", error: error.message });
  }
};