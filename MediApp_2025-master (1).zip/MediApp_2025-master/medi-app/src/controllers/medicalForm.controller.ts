// backend/src/controllers/medicalForms.controller.ts
import { Request, Response } from "express";
import MedicalForm, { IMedicalForm } from "../models/medicalForm.model";
import User, { IUser } from "../models/user.model";
import crypto from "crypto";
import { sendEmail } from "../services/email.service";

export const createMedicalForm = async (req: Request, res: Response) => {
  try {
    const {
      nombreCompleto,
      cedula,
      correo,
      contactoEmergencia,
      sexo,
      fechaNacimiento,
      ...medicalData
    } = req.body;

    // Check for existing user by email or cedula
    let user = (await User.findOne({ email: correo })) as IUser | null;
    if (!user) {
      user = (await User.findOne({ cedula })) as IUser | null;
    }

    if (user) {
      // Update user details if necessary
      user.nombreCompleto = nombreCompleto;
      user.cedula = cedula;
      user.email = correo;
      user.contactoEmergencia = contactoEmergencia;
      user.sexo = sexo;
      user.fechaNacimiento = fechaNacimiento;
      await user.save();
    } else {
      // Create new user
      const confirmationToken = crypto.randomBytes(20).toString("hex");
      user = new User({
        username: nombreCompleto.toLowerCase().replace(/\s+/g, ""),
        email: correo,
        password: "defaultPassword", // Replace with a secure password generation strategy
        role: "patient",
        cedula,
        contactoEmergencia,
        sexo,
        nombreCompleto,
        fechaNacimiento,
        confirmationToken,
        confirmationTokenExpires: new Date(Date.now() + 24 * 3600000), // 24 hours
        status: "pending",
      });
      await user.save();

      // Send confirmation email for new user
      const subject = "Confirma tu cuenta";
      const text = `Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el siguiente enlace:\n\n
                    ${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}\n\n
                    Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.\n`;
      const html = `
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
          <h2 style="text-align: center; color: #007bff;">Confirma tu Cuenta</h2>
          <p>Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el botón de abajo:</p>
          <div style="text-align: center; margin: 20px 0;">
            <a href="${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}" 
               style="display: inline-block; padding: 10px 20px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">
              Confirmar Correo
            </a>
          </div>
          <p>Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.</p>
        </div>
      `;
      await sendEmail(correo, subject, text, html);
    }

    // Check for existing medical form for this user
    const existingForm = await MedicalForm.findOne({ paciente: user._id });
    if (existingForm) {
      return res.status(400).json({
        message: "Ya existe un formulario médico para este paciente",
      });
    }

    // Create and save the new medical form
    const newForm = new MedicalForm({
      ...medicalData,
      paciente: user._id,
    }) as IMedicalForm;
    await newForm.save();

    res.status(201).json({
      message: "Formulario creado exitosamente",
      data: newForm,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(500).json({
      message: "Error al crear el formulario o el usuario",
      error: errorMessage,
    });
  }
};

export const getMedicalForms = async (req: Request, res: Response) => {
  try {
    const forms = await MedicalForm.find().populate(
      "paciente",
      "nombreCompleto cedula email contactoEmergencia sexo fechaNacimiento"
    );
    res.status(200).json(forms);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(500).json({ message: "Error al obtener formularios", error: errorMessage });
  }
};

export const getMedicalFormById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const form = await MedicalForm.findById(id).populate(
      "paciente",
      "nombreCompleto cedula email contactoEmergencia sexo fechaNacimiento"
    );

    if (!form) {
      res.status(404).json({ message: "Formulario no encontrado" });
      return;
    }

    res.status(200).json(form);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(500).json({ message: "Error al obtener el formulario", error: errorMessage });
  }
};

export const updateMedicalForm = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const updatedForm = await MedicalForm.findByIdAndUpdate(id, req.body, { new: true }).populate(
      "paciente",
      "nombreCompleto cedula email contactoEmergencia sexo fechaNacimiento"
    );

    if (!updatedForm) {
      res.status(404).json({ message: "Formulario no encontrado" });
      return;
    }

    res.status(200).json({
      message: "Formulario actualizado exitosamente",
      data: updatedForm,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(500).json({ message: "Error al actualizar el formulario", error: errorMessage });
  }
};

export const deleteMedicalForm = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const deletedForm = await MedicalForm.findByIdAndDelete(id);

    if (!deletedForm) {
      res.status(404).json({ message: "Formulario no encontrado" });
      return;
    }

    res.status(200).json({ message: "Formulario eliminado exitosamente" });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(500).json({ message: "Error al eliminar el formulario", error: errorMessage });
  }
};