import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/user.model";
import crypto from "crypto";
import { sendEmail } from "../services/email.service";

// Updated registerUser
export const registerUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, email, password, role, cedula, contactoEmergencia, sexo, nombreCompleto, fechaNacimiento } = req.body;

    // Validate required fields
    if (!username || !email || !password || !role || !cedula || !contactoEmergencia || !sexo || !nombreCompleto || !fechaNacimiento) {
      res.status(400).json({ message: "Todos los campos son obligatorios" });
      return;
    }

    // Validate email format
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
      res.status(400).json({ message: "Por favor, ingresa un correo válido" });
      return;
    }

    // Validate cedula (minimum 5 characters, numbers and hyphens)
    if (!/^[0-9-]{5,}$/.test(cedula)) {
      res.status(400).json({ message: "La cédula debe tener al menos 5 caracteres y contener solo números y guiones" });
      return;
    }

    // Validate contactoEmergencia (numbers, +, -, spaces)
    if (!/^[0-9+-\s]+$/.test(contactoEmergencia)) {
      res.status(400).json({ message: "El contacto de emergencia debe contener solo números, +, - o espacios" });
      return;
    }

    // Validate sexo
    if (!["Masculino", "Femenino", "Otro"].includes(sexo)) {
      res.status(400).json({ message: "El sexo debe ser Masculino, Femenino u Otro" });
      return;
    }

    // Validate nombreCompleto (letters and spaces, 3-100 characters)
    if (!/^[a-zA-Z\s]{3,100}$/.test(nombreCompleto)) {
      res.status(400).json({ message: "El nombre completo debe contener solo letras y espacios, y tener entre 3 y 100 caracteres" });
      return;
    }

    // Validate fechaNacimiento (not future, reasonable age)
    const birthDate = new Date(fechaNacimiento);
    const today = new Date();
    if (birthDate > today) {
      res.status(400).json({ message: "La fecha de nacimiento no puede ser futura" });
      return;
    }
    const age = today.getFullYear() - birthDate.getFullYear();
    if (age > 120) {
      res.status(400).json({ message: "La edad no puede ser mayor a 120 años" });
      return;
    }

    // Check for existing user by email or cedula
    const existingUser = await User.findOne({ $or: [{ email }, { cedula }] });
    if (existingUser) {
      res.status(400).json({ message: "El correo o la cédula ya están en uso" });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const confirmationToken = crypto.randomBytes(20).toString('hex');

    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      role,
      cedula,
      contactoEmergencia,
      sexo,
      nombreCompleto,
      fechaNacimiento,
      confirmationToken,
      confirmationTokenExpires: new Date(Date.now() + 24 * 3600000), // 24 hours
      status: "pending",
    });

    await newUser.save();

    // Send confirmation email
    const subject = 'Confirma tu cuenta';
    const text = `Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el siguiente enlace:\n\n
                  ${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}\n\n
                  Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.\n`;
    const html = `
      <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <h2 style="text-align: center; color: #007bff;">Confirma tu Cuenta</h2>
        <p>Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el botón de abajo:</p>
        <div style="text-align: center; margin: 20px 0;">
          <a href="${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}" 
             style="display: inline-block; padding: 10px 20px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">
            Confirmar Correo
          </a>
        </div>
        <p>Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.</p>
      </div>
    `;

    await sendEmail(email, subject, text, html);

    res.status(201).json({
      message: "Usuario registrado. Por favor verifica tu correo para activar tu cuenta",
      user: {
        id: newUser._id,
        username: newUser.username,
        email: newUser.email,
        role: newUser.role,
        cedula: newUser.cedula,
        contactoEmergencia: newUser.contactoEmergencia,
        sexo: newUser.sexo,
        nombreCompleto: newUser.nombreCompleto,
        fechaNacimiento: newUser.fechaNacimiento,
        status: newUser.status,
      },
    });
  } catch (error) {
    console.error("Error al registrar usuario:", error);
    res.status(500).json({ message: "Error del servidor" });
  }
};

// New confirmEmail endpoint
export const confirmEmail = async (req: Request, res: Response): Promise<void> => {
  try {
    const { token } = req.params;

    const user = await User.findOne({
      confirmationToken: token,
      confirmationTokenExpires: { $gt: Date.now() },
    });

    if (!user) {
      res.status(400).json({ message: "El token de confirmación es inválido o ha expirado" });
      return;
    }

    user.status = "active";
    user.confirmationToken = undefined;
    user.confirmationTokenExpires = undefined;
    await user.save();

    const jwtToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET || "secret", {
      expiresIn: "1d",
    });

    res.status(200).json({
      message: "Correo confirmado exitosamente",
      token: jwtToken,
    });
  } catch (error) {
    console.error("Error al confirmar correo:", error);
    res.status(500).json({ message: "Error del servidor" });
  }
};

// Updated loginUser
export const loginUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      res.status(404).json({ message: "Usuario no encontrado" });
      return;
    }

    if (user.status === "pending") {
      res.status(403).json({ message: "Por favor confirma tu correo electrónico primero" });
      return;
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      res.status(401).json({ message: "Contraseña incorrecta" });
      return;
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || "secret", {
      expiresIn: "1d",
    });

    res.status(200).json({
      message: "Inicio de sesión exitoso",
      user: { id: user._id, username: user.username, email: user.email, role: user.role },
      token,
    });
  } catch (error) {
    console.error("Error en el login:", error);
    res.status(500).json({ message: "Error del servidor" });
  }
};

export const getUserInfo = async (req: Request, res: Response): Promise<void> => {
    try {

        const userId = (req as Request & { userId: string }).userId;
        //console.log("ID del usuario recibido:", userId); // Verifica si el ID del usuario llega correctamente

        if (!userId) {
            res.status(400).json({ message: "Usuario no autenticado" });
            return;
        }

        const user = await User.findById(userId, "-password"); // Excluir contraseña
        if (!user) {
            res.status(404).json({ message: "Usuario no encontrado" });
            return;
        }

        res.status(200).json({
            message: "Información del usuario obtenida correctamente",
            user,
        });
    } catch (error) {
        console.error("Error al obtener información del usuario:", error);
        res.status(500).json({ message: "Error del servidor" });
    }
};

export const forgotPassword = async (req: Request, res: Response): Promise<void> => {
    const { email } = req.body;
  
    try {
      const user = await User.findOne({ email });
      if (!user) {
        res.status(404).json({ message: "Usuario no encontrado" });
        return;
      }
  
      const token = crypto.randomBytes(20).toString('hex');
      user.resetPasswordToken = token;
      user.resetPasswordExpires = new Date(Date.now() + 3600000); // 1 hora
      await user.save();
  
      const subject = 'Restablecimiento de contraseña';
      const text = `Recibió este correo electrónico porque usted (u otra persona) solicitó el restablecimiento de la contraseña de su cuenta.\n\n
                    Haga clic en el siguiente enlace, o péguelo en su navegador para completar el proceso:\n\n
                    ${process.env.FRONTEND_URL}/auth/reset-password/${token}\n\n
                    Si no solicitó esto, ignore este correo electrónico y su contraseña permanecerá sin cambios.\n`;
      const html = `
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; color: #333; background-color: #f7f7f7; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
          <h2 style="text-align: center; color: #007bff;">Restablecimiento de Contraseña</h2>
          <p>Has recibido este correo electrónico porque usted (u otra persona) solicitó el restablecimiento de la contraseña de su cuenta.</p>
          <p>Haga clic en el siguiente enlace, o péguelo en su navegador para completar el proceso:</p>
          <div style="text-align: center; margin: 20px 0;">
            <a href="${process.env.FRONTEND_URL}/auth/reset-password/${token}" style="display: inline-block; padding: 10px 20px; font-size: 16px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">Restablecer Contraseña</a>
          </div>
          <p>Si no solicitó esto, ignore este correo electrónico y su contraseña permanecerá sin cambios.</p>
          <p>El token tiene una validez hasta de 1 hora para realizar los cambios.</p>
        </div>
      `;
  
      await sendEmail(user.email, subject, text, html);
  
      res.status(200).json({ message: "Correo de restablecimiento de contraseña enviado" });
    } catch (error) {
      res.status(500).json({ message: "Error al enviar el correo de restablecimiento de contraseña" });
    }
  };
  
  export const resetPassword = async (req: Request, res: Response): Promise<void> => {
    const { token } = req.params;
    const { password } = req.body;
  
    try {
      const user = await User.findOne({
        resetPasswordToken: token,
        resetPasswordExpires: { $gt: Date.now() },
      });
  
      if (!user) {
        res.status(400).json({ message: "El token de restablecimiento de contraseña es no válido o ha expirado" });
        return;
      }
  
      user.password = await bcrypt.hash(password, 10);
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();
  
      res.status(200).json({ message: "Contraseña restablecida exitosamente" });
    } catch (error) {
      res.status(500).json({ message: "Error al restablecer la contraseña" });
    }
  };

