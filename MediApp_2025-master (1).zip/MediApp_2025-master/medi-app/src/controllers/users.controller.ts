import { Request, Response } from "express";
import User from "../models/user.model";

interface AuthenticatedRequest extends Request {
  userId?: string;
}

export const getPatients = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const userId = req.userId;
    if (!userId) {
      res.status(401).json({ message: "Usuario no autenticado" });
      return;
    }

    const user = await User.findById(userId);
    if (!user || user.role !== "admin") {
      res.status(403).json({ message: "Acceso denegado. Solo administradores pueden ver pacientes." });
      return;
    }

    const patients = await User.find({ role: "patient" }, "username email role cedula fechaNacimiento");
    res.status(200).json(patients);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener los pacientes", error });
  }
}; 