import User from "../models/user.model";
import { IUser } from "../models/user.model";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { sendEmail } from "./email.service";

interface UserCreationData {
  username: string;
  email: string;
  password?: string; // Optional, as we may generate one
  role: string;
}

export const createUserService = async (data: UserCreationData): Promise<IUser> => {
  const { username, email, password, role } = data;

  // Check if the email already exists
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    throw new Error("El correo ya está en uso");
  }

  // Generate a password if not provided
  const finalPassword = password || crypto.randomBytes(8).toString("hex");
  const hashedPassword = await bcrypt.hash(finalPassword, 10);
  const confirmationToken = crypto.randomBytes(20).toString("hex");

  // Create the new user
  const newUser = new User({
    username,
    email,
    password: hashedPassword,
    role,
    confirmationToken,
    confirmationTokenExpires: new Date(Date.now() + 24 * 3600000), // 24 hours
    status: "pending",
  }) as IUser; // Type assertion to ensure newUser is IUser

  await newUser.save();

  // Send confirmation email with detailed template from registerUser
  const subject = "Confirma tu cuenta";
  const text = `Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el siguiente enlace:\n\n
                ${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}\n\n
                Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.\n`;
  const html = `
    <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
      <h2 style="text-align: center; color: #007bff;">Confirma tu Cuenta</h2>
      <p>Gracias por registrarte. Por favor confirma tu correo electrónico haciendo clic en el botón de abajo:</p>
      <div style="text-align: center; margin: 20px 0;">
        <a href="${process.env.FRONTEND_URL}/auth/confirm/${confirmationToken}" 
           style="display: inline-block; padding: 10px 20px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">
          Confirmar Correo
        </a>
      </div>
      <p>Este enlace expirará en 24 horas. Si no creaste esta cuenta, puedes ignorar este mensaje.</p>
    </div>
  `;

  await sendEmail(email, subject, text, html);

  return newUser;
};