import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

// Configuración del transporte con AWS SES SMTP
const transporter = nodemailer.createTransport({
  host: "email-smtp.us-east-1.amazonaws.com", // Replace <region> with your SES region, e.g., us-east-1
  port: 587, // SES supports 465 (SSL), 587 (TLS), or 25
  secure: false, // Use true for port 465, false for 587 or 25 with STARTTLS
  auth: {
    user: process.env.SES_SMTP_USER, // Your SES SMTP Username
    pass: process.env.SES_SMTP_PASS, // Your SES SMTP Password
  },
  logger: true, // Enable logs
  debug: true,  // Enable debugging
});

// Función para enviar correos
export const sendEmail = async (to: string, subject: string, text: string, html?: string) => {
  try {
    const mailOptions = {
      from: `"Dr. Marlon Jiménez Rojas" <${process.env.EMAIL_FROM}>`, // Customize the sender name and email
      to,
      subject,
      text,
      html,
    };

    await transporter.sendMail(mailOptions);
    console.log("Correo enviado correctamente");
  } catch (error) {
    console.error("Error al enviar el correo:", error);
    throw new Error("No se pudo enviar el correo");
  }
};