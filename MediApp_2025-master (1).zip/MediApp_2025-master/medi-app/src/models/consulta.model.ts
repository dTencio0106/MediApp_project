import mongoose, { Schema, Document, Types } from "mongoose";

export interface IConsulta extends Document {
  paciente: Types.ObjectId; // Changed to ObjectId referencing User
  doctor: string; // Siempre será "Marlon Jimenez"
  sistolica: number;
  diastolica: number;
  frecuenciaCardiaca: number;
  saturacionOxigeno: string;
  temperatura: string;
  motivo: string;
  fecha: Date;
}

const ConsultaSchema: Schema = new Schema(
  {
    paciente: { type: Schema.Types.ObjectId, ref: "User", required: true }, // Reference to User model
    doctor: { type: String, required: true, default: "Marlon Jimenez" },
    sistolica: { type: Number, required: true },
    diastolica: { type: Number, required: true },
    frecuenciaCardiaca: { type: Number, required: true },
    saturacionOxigeno: { type: String, required: true },
    temperatura: { type: String, required: true },
    motivo: { type: String, required: true },
    fecha: { type: Date, required: true },
  },
  { timestamps: true }
);

export default mongoose.model<IConsulta>("Consulta", ConsultaSchema);