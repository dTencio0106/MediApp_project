import mongoose, { Document, Schema, Types } from "mongoose";

// Define the IUser interface
export interface IUser extends Document {
  _id: Types.ObjectId;
  username: string;
  email: string; // Maps to 'correo'
  password: string;
  role: string;
  cedula: string;
  contactoEmergencia: string;
  sexo: string;
  nombreCompleto: string;
  fechaNacimiento: string; // Added fechaNacimiento
  resetPasswordToken?: string;
  resetPasswordExpires?: Date;
  confirmationToken?: string;
  confirmationTokenExpires?: Date;
  status: string;
}

const UserSchema = new Schema<IUser>(
  {
    username: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ["admin", "user", "patient"], default: "user" },
    cedula: { type: String, required: true, unique: true },
    contactoEmergencia: { type: String, required: true },
    sexo: { type: String, required: true },
    nombreCompleto: { type: String, required: true },
    fechaNacimiento: { type: String, required: true }, // Added fechaNacimiento
    resetPasswordToken: { type: String },
    resetPasswordExpires: { type: Date },
    confirmationToken: { type: String },
    confirmationTokenExpires: { type: Date },
    status: {
      type: String,
      enum: ["pending", "active"],
      default: "pending",
    },
  },
  { timestamps: true }
);

export default mongoose.model<IUser>("User", UserSchema);