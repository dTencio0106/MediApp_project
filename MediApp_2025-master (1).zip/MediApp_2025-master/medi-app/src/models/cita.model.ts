import mongoose, { Schema, Document, Types } from "mongoose";

export interface ICita extends Document {
  titulo: string;
  fechaHora: Date;
  descripcion: string;
  paciente: Types.ObjectId;
  creadaPor: Types.ObjectId;
}

const CitaSchema: Schema = new Schema(
  {
    titulo: { type: String, required: true },
    fechaHora: { type: Date, required: true },
    descripcion: { type: String, required: true },
    paciente: { type: Schema.Types.ObjectId, ref: "User", required: true }, // Add user reference
    creadaPor:{ type: Schema.Types.ObjectId, ref: "User", required: true }, // Add user reference
  },
  { timestamps: true }
);

export default mongoose.model<ICita>("Cita", CitaSchema);
