import { Schema, model, Document, Types } from "mongoose";

export interface IMedicalForm extends Document {
  patologias: string;
  alergias: string;
  cirugias: string;
  inmunizaciones: string;
  tabaco: string;
  alcohol: string;
  drogas: string;
  actividadFisica: string;
  observaciones: string;
  paciente: Types.ObjectId; // Reference to the User model
}

const MedicalFormSchema = new Schema(
  {
    patologias: { type: String },
    alergias: { type: String },
    cirugias: { type: String },
    inmunizaciones: { type: String },
    tabaco: { type: String },
    alcohol: { type: String },
    drogas: { type: String },
    actividadFisica: { type: String },
    observaciones: { type: String },
    paciente: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true }
);

export default model<IMedicalForm>("MedicalForm", MedicalFormSchema);