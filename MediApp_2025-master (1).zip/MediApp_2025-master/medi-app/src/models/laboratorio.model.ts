import mongoose, { Document, Schema, Types } from "mongoose";

export interface ILaboratorio extends Document {
  paciente: Types.ObjectId; // Changed to ObjectId referencing User
  archivos: string[];
}

const LaboratorioSchema: Schema = new Schema({
  paciente: { type: Schema.Types.ObjectId, ref: "User", required: true }, // Reference to User model
  archivos: [
    {
      type: String,
      required: true,
    },
  ],
},
  { timestamps: true }
);

const Laboratorio = mongoose.model<ILaboratorio>("Laboratorio", LaboratorioSchema);

export default Laboratorio;